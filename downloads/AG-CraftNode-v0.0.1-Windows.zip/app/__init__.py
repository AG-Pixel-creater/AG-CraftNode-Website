"""Application package for AG CraftNode."""
