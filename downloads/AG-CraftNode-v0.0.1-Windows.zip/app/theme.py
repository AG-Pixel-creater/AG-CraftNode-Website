THEMES = {
    "dark": {
        "window": "#141B22", "fg": "#DDE4EA", "border": "#31404D",
        "sidebar": "#1C262F", "sidebar_fg": "#90A4AE", "sidebar_h": "#26333E", "sidebar_a": "#2E3D49",
        "panel": "#1F2A34", "panel_alt": "#26333F", "panel_fg": "#E8EEF3", "panel_sub": "#8FA3B0",
        "input_bg": "#0F151B", "input_fg": "#DDE4EA", "btn_bg": "#222E39",
        "accent": "#1E88E5", "accent_h": "#1565C0", "accent_bright": "#64B5F6",
        "red": "#E91E63", "red_h": "#C2185B", "green": "#2ECC71", "green_h": "#27AE60",
        "orange": "#F57C00", "orange_h": "#E65100", "purple": "#8E24AA", "purple_h": "#6A1B9A",
        "console_bg": "#04080B", "console_fg": "#6FE38B",
    },
    "light": {
        "window": "#ECEDEF", "fg": "#263238", "border": "#B9C4CC",
        "sidebar": "#2C3A47", "sidebar_fg": "#B0BEC5", "sidebar_h": "#37474F", "sidebar_a": "#40525F",
        "panel": "#2C3A47", "panel_alt": "#354655", "panel_fg": "#FFFFFF", "panel_sub": "#AEBDC7",
        "input_bg": "#FFFFFF", "input_fg": "#263238", "btn_bg": "#FFFFFF",
        "accent": "#1E88E5", "accent_h": "#1565C0", "accent_bright": "#42A5F5",
        "red": "#E91E63", "red_h": "#C2185B", "green": "#2ECC71", "green_h": "#27AE60",
        "orange": "#F57C00", "orange_h": "#E65100", "purple": "#8E24AA", "purple_h": "#6A1B9A",
        "console_bg": "#10171D", "console_fg": "#7CFC9E",
    },
}


def build_qss(p):
    return f"""
QMainWindow,QDialog{{background:{p['window']};}}
QWidget{{color:{p['fg']};font-family:'Segoe UI';font-size:13px;}}
QToolTip{{background:{p['panel']};color:{p['panel_fg']};border:1px solid {p['border']};padding:4px;}}
#TopHeader{{background:{p['sidebar']};border-bottom:1px solid {p['sidebar_a']};}}
#Logo{{color:#FFFFFF;font-size:20px;font-weight:bold;}}
#HeaderNav{{background:transparent;border:none;color:{p['sidebar_fg']};font-weight:bold;font-size:13px;padding:8px 12px;border-radius:4px;}}
#HeaderNav:hover{{color:#FFFFFF;background:{p['sidebar_h']};}}
#HeaderToggle{{background:transparent;border:1px solid #4A5B68;border-radius:4px;color:#CFD8DC;padding:5px 12px;font-weight:bold;}}
#HeaderToggle:hover{{color:#FFFFFF;border-color:{p['accent']};}}
#Promo{{background:#0E141A;color:#90A4AE;border:1px solid #26333E;border-radius:6px;padding:8px 18px;font-size:12px;}}
#Sidebar{{background:{p['sidebar']};border-right:1px solid {p['sidebar_a']};}}
#SideName{{color:#FFFFFF;font-weight:bold;font-size:15px;padding:16px;border-bottom:1px solid {p['sidebar_a']};}}
#SideBack{{background:transparent;border:none;color:{p['sidebar_fg']};text-align:left;padding:10px 18px;font-weight:bold;}}
#SideBack:hover{{color:#FFFFFF;background:{p['sidebar_h']};}}
#SidebarBtn{{background:transparent;border:none;color:{p['sidebar_fg']};text-align:left;padding:11px 18px;font-size:13px;border-radius:0px;font-weight:normal;}}
#SidebarBtn:hover{{background:{p['sidebar_h']};color:#FFFFFF;}}
#SidebarBtnActive{{background:{p['sidebar_a']};color:#FFFFFF;border:none;border-left:3px solid {p['accent']};text-align:left;padding:11px 18px;font-size:13px;font-weight:bold;border-radius:0px;}}
QPushButton{{background:{p['btn_bg']};color:{p['fg']};border:1px solid {p['border']};border-radius:5px;padding:7px 14px;}}
QPushButton:hover{{border-color:{p['accent']};}}
QPushButton:disabled{{color:{p['border']};}}
#HelpBtn,#BtnBlue,#CreateBtn{{background:{p['accent']};color:#FFFFFF;border:none;border-radius:5px;padding:8px 20px;font-weight:bold;}}
#HelpBtn:hover,#BtnBlue:hover,#CreateBtn:hover{{background:{p['accent_h']};}}
#BtnRed,#DangerBtn{{background:{p['red']};color:#FFFFFF;border:none;border-radius:5px;padding:8px 16px;font-weight:bold;}}
#BtnRed:hover,#DangerBtn:hover{{background:{p['red_h']};}}
#BtnGreen,#GreenBtn{{background:{p['green']};color:#FFFFFF;border:none;border-radius:5px;padding:8px 16px;font-weight:bold;}}
#BtnGreen:hover,#GreenBtn:hover{{background:{p['green_h']};}}
#BtnOrange,#WarnBtn{{background:{p['orange']};color:#FFFFFF;border:none;border-radius:5px;padding:8px 16px;font-weight:bold;}}
#BtnOrange:hover,#WarnBtn:hover{{background:{p['orange_h']};}}
#BtnPurple,#PurpleBtn{{background:{p['purple']};color:#FFFFFF;border:none;border-radius:5px;padding:8px 16px;font-weight:bold;}}
#BtnPurple:hover,#PurpleBtn:hover{{background:{p['purple_h']};}}
#StartBtn,#BigStart{{background:{p['green']};color:#FFFFFF;border:none;border-radius:8px;padding:12px 34px;font-weight:bold;font-size:16px;min-width:200px;min-height:48px;}}
#StartBtn:hover,#BigStart:hover{{background:{p['green_h']};}}
#StopBtn,#BigStop{{background:{p['red']};color:#FFFFFF;border:none;border-radius:8px;padding:12px 34px;font-weight:bold;font-size:16px;min-width:200px;min-height:48px;}}
#StopBtn:hover,#BigStop:hover{{background:{p['red_h']};}}
#CopyBtn{{background:{p['accent']};color:#FFFFFF;border:none;border-radius:4px;padding:5px 14px;font-weight:bold;font-size:11px;}}
#CopyBtn:hover{{background:{p['accent_h']};}}
#DeleteBtn{{background:transparent;color:{p['panel_sub']};border:none;font-size:15px;font-weight:bold;padding:4px 8px;}}
#DeleteBtn:hover{{color:{p['red']};}}
#TabBtn{{border-radius:6px;padding:10px 18px;font-weight:bold;font-size:13px;}}
#IconBtn{{background:{p['accent']};color:#FFFFFF;border:none;border-radius:4px;padding:5px 12px;font-weight:bold;}}
#IconBtn:hover{{background:{p['accent_h']};}}
#IconBtnRed{{background:{p['red']};color:#FFFFFF;border:none;border-radius:4px;padding:5px 12px;font-weight:bold;}}
#IconBtnRed:hover{{background:{p['red_h']};}}
QLineEdit,QComboBox,QSpinBox{{background:{p['input_bg']};border:1px solid {p['border']};border-radius:4px;padding:6px;color:{p['input_fg']};min-height:20px;selection-background-color:{p['accent']};}}
QLineEdit:focus,QComboBox:focus,QSpinBox:focus{{border-color:{p['accent']};}}
QComboBox QAbstractItemView{{background:{p['input_bg']};color:{p['input_fg']};border:1px solid {p['border']};selection-background-color:{p['accent']};selection-color:#FFFFFF;}}
QCheckBox{{spacing:10px;padding:4px;}}
QCheckBox::indicator{{width:18px;height:18px;border-radius:3px;border:2px solid {p['border']};background:{p['input_bg']};}}
QCheckBox::indicator:checked{{background:{p['accent']};border-color:{p['accent']};}}
#StatusOffline{{background:{p['red']};color:#FFFFFF;font-weight:bold;padding:12px;border-radius:6px;font-size:15px;}}
#StatusOnline{{background:{p['green']};color:#FFFFFF;font-weight:bold;padding:12px;border-radius:6px;font-size:15px;}}
#StatusStarting{{background:{p['orange']};color:#FFFFFF;font-weight:bold;padding:12px;border-radius:6px;font-size:15px;}}
#PanelCard{{background:{p['panel']};border-radius:8px;}}
#PanelTitle{{color:{p['panel_fg']};font-size:18px;font-weight:bold;}}
#PanelText{{color:{p['panel_fg']};}}
#PanelSub{{color:{p['panel_sub']};font-size:12px;}}
#PageTitle{{color:{p['accent']};font-size:28px;font-weight:bold;}}
#SectionTitle{{color:{p['accent']};font-size:16px;font-weight:bold;padding:8px 0px;}}
#InfoNote{{color:{p['accent_bright']};font-size:11px;padding:10px;background:{p['panel']};border-radius:6px;}}
#ServerCard{{background:{p['panel']};border-radius:8px;}}
#ServerCardTitle{{color:{p['panel_fg']};font-size:17px;font-weight:bold;}}
#ServerCardSub{{color:{p['panel_sub']};font-size:12px;}}
#StatCard{{background:{p['panel']};border-radius:8px;}}
"""
