from pathlib import Path

APP_NAME = "AG CraftNode"
APP_VERSION = "0.0.1"
DATA_FILE = "servers.json"
ACTIVITY_FILE = "activity.json"
SERVERS_DIR = "servers"
JAVA_DIR = "java"
TOOLS_DIR = "tools"
BACKUPS_DIR = "backups"
CONFIG_FILE = "config.json"
USER_AGENT = "AGCraftNode/0.0.1"
REQUIRED_JAVA = 25

ROOT_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = ROOT_DIR / "assets"


def asset_path(filename: str) -> str:
    return str((ASSETS_DIR / filename).resolve())


ICON_PATH = asset_path("icon.ico")
