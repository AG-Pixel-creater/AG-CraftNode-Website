import sys, os, json, socket, shutil, platform, zipfile, subprocess, re, time, datetime, urllib.request, urllib.error, urllib.parse, webbrowser, random, string
os.environ.setdefault('PYTHONIOENCODING', 'utf-8')
if sys.platform == 'win32':
    # python.exe is DPI-unaware by manifest; Qt still renders at the real monitor
    # DPI, so its 1.25x surface gets clipped into the unscaled window (right-side
    # widgets vanish in RTL). Become PerMonitorV2-aware before QApplication so
    # Windows scales the window to match Qt's rendering.
    try:
        import ctypes
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QStackedWidget, QFrame, QGridLayout, QDialog, QLineEdit, QCheckBox, QComboBox,
    QMessageBox, QFormLayout, QPlainTextEdit, QProgressBar, QSpinBox, QScrollArea, QFileDialog,
    QListWidget, QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QSplitter,
    QSplashScreen, QTextEdit)
from PyQt6.QtCore import Qt, pyqtSignal, QProcess, QThread, QTimer, QObject
from PyQt6.QtGui import QCursor, QPixmap, QColor, QIcon

from app.config import (
    APP_NAME,
    APP_VERSION,
    ACTIVITY_FILE,
    BACKUPS_DIR,
    CONFIG_FILE,
    DATA_FILE,
    ICON_PATH,
    JAVA_DIR,
    REQUIRED_JAVA,
    SERVERS_DIR,
    TOOLS_DIR,
    USER_AGENT,
)
from app.theme import THEMES, build_qss

# ============ I18N (English LTR / Urdu RTL) ============
CURRENT_LANG = "en"
def tr(k): return TR.get(CURRENT_LANG, {}).get(k) or TR["en"].get(k) or k

def apply_theme(app):
    cfg = load_config()
    app.setStyleSheet(build_qss(THEMES.get(cfg.get("theme", "dark"), THEMES["dark"])))

def apply_language(app):
    global CURRENT_LANG
    CURRENT_LANG = load_config().get("language", "en")
    app.setLayoutDirection(Qt.LayoutDirection.RightToLeft if CURRENT_LANG == "ur" else Qt.LayoutDirection.LeftToRight)

def restart_app():
    try: os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception: QMessageBox.information(None, "AG CraftNode", tr("msg_restart_manual"))

# ============ I18N (English / اردو) ============
TR = {
"en": {
 "app_name":"AG CraftNode","msg_restart_manual":"Restart the app manually to apply language.",
 # header / nav
 "hdr_servers":"Servers","hdr_tools":"Tools","hdr_settings":"Settings","hdr_help":"Help",
 "nav_dashboard":"Dashboard","nav_console":"Console","nav_players":"Players","nav_worlds":"Worlds",
 "nav_backups":"Backups","nav_plugins":"Plugins","nav_performance":"Performance","nav_options":"Options",
 "nav_logs":"Logs","nav_files":"Files","nav_scheduler":"Scheduler","nav_networking":"Networking",
 "nav_cloud":"Cloud","nav_activity":"Activity",
 # common buttons
 "btn_start":"Start","btn_stop":"Stop","btn_restart":"Restart","btn_save":"Save","btn_delete":"Delete",
 "btn_refresh":"Refresh","btn_create":"+ Create","btn_import":"Import","btn_cancel":"Cancel",
 "btn_browse":"Browse","btn_send":"Send","btn_clear":"Clear","btn_add":"Add","btn_remove":"Remove",
 "btn_download":"Download","btn_upload":"Upload","btn_search":"Search","btn_copy":"Copy",
 "btn_install_sel":"Install Selected","btn_install_all":"Install ALL Visible","btn_configure":"Configure rclone",
 # status
 "st_offline":"Offline","st_online":"Online","st_starting":"Starting","st_pending":"Address pending...",
 "tunnel_bore":"🌐 Bore (Dynamic - new address each restart)",
 "tunnel_serveo":"📌 Serveo (Fixed - same address always)",
 "tunnel_playit":"🎯 playit.gg (Random domain after setup)",
 "tunnel_none":"🔒 None (LAN only)",
 "tunnel_note":"🌐 Bore: new address on every restart\n📌 Serveo: fixed subdomain (like mycraft.serveo.net)\n🎯 playit: random domain\n🔒 None: LAN only",
 # servers page
 "page_servers":"Servers","ph_search":"Search...","no_servers":"No Servers","lbl_local_ip":"Local IP",
 # create / import dialogs
 "create_title":"Create Server","lbl_name":"Server Name","ph_name":"My_Server","lbl_template":"Template",
 "lbl_version":"Version","lbl_ram":"RAM (GB)","lbl_port":"Port","lbl_tunnel":"Tunnel","sep_tunnel":"─── Tunnel ───",
 "sep_bedrock":"─── Bedrock/PE ───","chk_bedrock":"Enable Bedrock/PE (GeyserMC + Floodgate auto)",
 "ph_subdomain":"mycraft  (Fixed mode - lowercase a-z, 0-9)",
 "import_title":"Import Server","lbl_path":"Server folder path",
 # console
 "ph_command":"Command + Enter",
 # players
 "ph_player":"Player name...","btn_whitelist":"Whitelist","btn_ops":"OPs","btn_banned":"Banned",
 "btn_banned_ips":"Banned IPs","err_player_name":"Enter player name!","btn_kick":"Kick","btn_unban":"Unban",
 "tab_all_known":"All Known","no_reason":"No reason",
 # worlds / backups
 "worlds_title":"Worlds Manager",
 "worlds_note":"Nether/End appear when a player uses a portal.",
 "btn_open":"Open","btn_folder":"Folder","col_world":"World","col_type":"Type","col_size":"Size","col_path":"Path",
 "msg_install_rclone":"Install rclone first",
 "btn_backup_now":"Backup Now","btn_restore":"Restore","confirm_restore":"Restore '{name}'?",
 # plugins
 "tab_catalog":"📚 Catalog","tab_search":"🔍 Search","tab_installed":"📦 Installed","tab_url":"🔗 URL",
 "ph_cat_search":"🔍 Search catalog...","lbl_category":"Cat:","lbl_mc":"MC:","all_categories":"All Categories",
 "auto":"Auto","lbl_url":"Direct .jar URL:","err_select_plugins":"Select plugin(s) first!",
 "err_select_server":"Select server!","install_all_title":"Install ALL",
 "install_all_msg":"Install {n} plugins? This will take time.","msg_all_installed":"All plugins installed!",
 "msg_installing_name":"Installing {name}","ph_modrinth":"Modrinth search...",
 "col_name":"Name","col_author":"Author","col_downloads":"Downloads","col_description":"Description",
 "col_status":"Status","btn_open_folder":"Open Folder","btn_clean":"Clean Corrupted",
 "btn_toggle":"Enable/Disable","btn_update_all":"Update All","st_installed":"✓ installed",
 "st_enabled":"enabled","st_disabled":"DISABLED",
 "msg_geyser":"Geyser config auto-edited!","msg_downloaded":"Downloaded {fn}",
 "msg_update_hint":"Manual: delete the plugin, then reinstall from Catalog.",
 "msg_clean":"{n} removed",
 # options
 "chk_whitelist":"Whitelist","chk_cracked":"Cracked","chk_pvp":"PvP","chk_flight":"Allow Flight",
 "chk_cmdblocks":"Command Blocks","chk_hardcore":"Hardcore","chk_nether":"Allow Nether","lbl_motd":"MOTD",
 "sec_tunnel":"🌍 Tunnel","sec_bedrock":"📱 Bedrock/PE","sec_world":"World","sec_resources":"Resources",
 "chk_bedrock":"Enable Bedrock (auto Geyser + Floodgate)","lbl_max_players":"Max Players",
 "lbl_gamemode":"Gamemode","lbl_difficulty":"Difficulty","lbl_viewdist":"View Distance",
 "lbl_simdist":"Simulation Distance","lbl_spawnprot":"Spawn Protection","lbl_max_ram":"Max RAM",
 "lbl_custom_java":"Custom Java",
 # scheduler
 "ph_time":"HH:MM","lbl_command":"Command",
 # networking / cloud / settings
 "net_info":"🌐 bore=Dynamic | 📌 serveo=Fixed (SSH) | 🎯 playit=Random",
 "btn_install_bore":"Install bore (Dynamic)","btn_install_rclone":"Install rclone",
 "chk_enable":"Enable","chk_auto_backup":"Auto-backup on stop","rclone_ok":"rclone ✓","rclone_missing":"rclone ✗",
 "ginfo_pending":"🌍 Java Global pending...",
 "chk_dictator":"Enable Dictator","chk_manual":"Force Manual Mode","chk_start_win":"Start with Windows",
 "lbl_tunnel_default":"Default Tunnel:","lbl_theme":"Theme","theme_dark":"Dark","theme_light":"Light",
 "lbl_language":"Language","lang_en":"English","lang_ur":"اردو",
 # server detail
 "lbl_server":"Server","lbl_local":"LOCAL:","lbl_java":"JAVA:","lbl_bedrock":"BEDROCK:",
 "btn_dl_jar":"Download JAR","btn_dl_java":"Download Java","jar_ready":"JAR Ready","java_ready":"Java Ready",
 "eula_title":"EULA","eula_msg":"Accept Mojang EULA?",
 # messages
 "err_error":"Error","err_invalid":"Invalid","err_missing":"Missing","msg_saved":"Saved!",
 "msg_restored":"Restored!","msg_exists":"Already exists!","msg_failed":"Failed!",
 "msg_stop_first":"Stop the server first!","confirm_delete":"Delete '{name}'?",
 "msg_uploading":"Uploading...","msg_installing":"Installing...","msg_result":"Result",
 "msg_no_issues":"No issues found","btn_latest":"Latest","btn_crashes":"Crashes","btn_analyze":"Analyze",
 "btn_up":"Up ⬆","msg_no_log":"No log file found","msg_no_crashes":"No crash reports",
 "iss_port":"Port in use","iss_java":"Java version mismatch","quit_title":"Quit","quit_msg":"Server running. Stop it?",
 "jar_not_found":"JAR not found","java_required":"Java {v} or newer is required",
 "locks_title":"Locked","locks_msg":"{n} lock(s) found. Continue?",
 "help_title":"Help",
 "help_text":"AG CraftNode - local Minecraft server manager.\n\n• Create a server from the Servers page\n• Start/Stop from the server page\n• Share the address with friends\n\nCloud backups need rclone configured.",
 # tools page
 "sec_tunnel_tools":"🌐 Tunnel Tools","sec_cloud":"☁ Cloud","sec_java":"☕ Java","sec_info":"📚 Info","sec_log":"Log",
 "btn_install_java":"Install Java","tool_ready":"✓ READY","tool_na":"✗ NOT AVAILABLE",
 "info_catalog":"Total plugins in catalog: {n}\nPlugins tab → 📚 Catalog",
 # dashboard stat labels
 "col_players":"Players","col_uptime":"Uptime","col_ram":"RAM",
 # misc
 "nav_back":"← Servers","tunnel_off":"Tunnel off",
 # activity
 "col_time":"Time","col_server":"Server","col_action":"Action","col_details":"Details",
 # networking
 "net_java_port":"Java Port:","net_lan":"LAN IP:","net_bedrock_port":"Bedrock Port:","net_mode":"Mode:",
 "net_status":"Status:","net_global":"Java Global:","net_bedrock":"Bedrock Global:",
 # settings sections
 "sec_appearance":"Appearance","sec_dictator":"Tunnel Dictator","sec_startup":"Startup",
},
"ur": {
 "app_name":"AG کرافٹ نوڈ","msg_restart_manual":"زبان بدلنے کے لیے ایپ دوبارہ شروع کریں۔",
 # header / nav
 "hdr_servers":"سرورز","hdr_tools":"اوزار","hdr_settings":"ترتیبات","hdr_help":"مدد",
 "nav_dashboard":"ڈیش بورڈ","nav_console":"کنسول","nav_players":"کھلاڑی","nav_worlds":"دنیاویں",
 "nav_backups":"بیک اپ","nav_plugins":"پلگ اِنز","nav_performance":"کارکردگی","nav_options":"آپشنز",
 "nav_logs":"لاگز","nav_files":"فائلیں","nav_scheduler":"شیڈولر","nav_networking":"نیٹ ورکنگ",
 "nav_cloud":"کلاؤڈ","nav_activity":"سرگرمی",
 # common buttons
 "btn_start":"شروع کریں","btn_stop":"بند کریں","btn_restart":"دوبارہ شروع کریں","btn_save":"محفوظ کریں",
 "btn_delete":"حذف کریں","btn_refresh":"تازہ کریں","btn_create":"+ نیا سرور","btn_import":"درآمد کریں",
 "btn_cancel":"منسوخ کریں","btn_browse":"براؤز کریں","btn_send":"بھیجیں","btn_clear":"صاف کریں",
 "btn_add":"شامل کریں","btn_remove":"ہٹائیں","btn_download":"ڈاؤن لوڈ","btn_upload":"اپ لوڈ",
 "btn_search":"تلاش کریں","btn_copy":"کاپی","btn_install_sel":"منتخب انسٹال کریں",
 "btn_install_all":"تمام نظر آنے والے انسٹال کریں","btn_configure":"rclone ترتیب دیں",
 # status
 "st_offline":"آف لائن","st_online":"آن لائن","st_starting":"شروع ہو رہا ہے","st_pending":"پتہ آ رہا ہے...",
 "tunnel_bore":"🌐 Bore (ڈائنامک - ہر بار نیا پتہ)",
 "tunnel_serveo":"📌 Serveo (فکسڈ - ہمیشہ ایک جیسا پتہ)",
 "tunnel_playit":"🎯 playit.gg (سیٹ اپ کے بعد رینڈم ڈومین)",
 "tunnel_none":"🔒 کوئی نہیں (صرف LAN)",
 "tunnel_note":"🌐 Bore: ہر بار نیا پتہ\n📌 Serveo: فکسڈ سب ڈومین (مثلاً mycraft.serveo.net)\n🎯 playit: رینڈم ڈومین\n🔒 کوئی نہیں: صرف LAN",
 # servers page
 "page_servers":"سرورز","ph_search":"تلاش...","no_servers":"کوئی سرور نہیں","lbl_local_ip":"مقامی IP",
 # create / import dialogs
 "create_title":"سرور بنائیں","lbl_name":"سرور کا نام","ph_name":"میرا_سرور","lbl_template":"ٹیمپلیٹ",
 "lbl_version":"ورژن","lbl_ram":"رام (GB)","lbl_port":"پورٹ","lbl_tunnel":"ٹنل","sep_tunnel":"─── ٹنل ───",
 "sep_bedrock":"─── بیڈراک/PE ───","chk_bedrock":"بیڈراک/PE فعال کریں (GeyserMC + Floodgate خودکار)",
 "ph_subdomain":"mycraft  (فکسڈ موڈ - چھوٹے حروف a-z, 0-9)",
 "import_title":"سرور درآمد کریں","lbl_path":"سرور فولڈر کا راستہ",
 # console
 "ph_command":"کمانڈ + انٹر",
 # players
 "ph_player":"کھلاڑی کا نام...","btn_whitelist":"وائٹ لسٹ","btn_ops":"آپرٹرز","btn_banned":"بین",
 "btn_banned_ips":"بین IPs","err_player_name":"کھلاڑی کا نام لکھیں!","btn_kick":"نکالیں","btn_unban":"ان بین کریں",
 "tab_all_known":"تمام معلوم","no_reason":"کوئی وجہ نہیں",
 # worlds / backups
 "worlds_title":"دنیاویں",
 "worlds_note":"نیدر/اینڈ تب نظر آتے ہیں جب کوئی کھلاڑی پورٹل استعمال کرتا ہے۔",
 "btn_open":"کھولیں","btn_folder":"فولڈر","col_world":"دنیا","col_type":"قسم","col_size":"سائز","col_path":"راستہ",
 "msg_install_rclone":"پہلے rclone انسٹال کریں",
 "btn_backup_now":"ابھی بیک اپ","btn_restore":"بحال کریں","confirm_restore":"کیا '{name}' بحال کریں؟",
 # plugins
 "tab_catalog":"📚 کیٹلاگ","tab_search":"🔍 تلاش","tab_installed":"📦 انسٹال شدہ","tab_url":"🔗 لنک",
 "ph_cat_search":"🔍 کیٹلاگ تلاش...","lbl_category":"کیٹ:","lbl_mc":"MC:","all_categories":"تمام کیٹگریز",
 "auto":"خودکار","lbl_url":"براہ راست .jar لنک:","err_select_plugins":"پہلے پلگ اِن منتخب کریں!",
 "err_select_server":"سرور منتخب کریں!","install_all_title":"تمام انسٹال کریں",
 "install_all_msg":"کیا {n} پلگ اِنز انسٹال کریں؟ اس میں وقت لگے گا۔","msg_all_installed":"تمام پلگ اِنز انسٹال ہو گئے!",
 "msg_installing_name":"{name} انسٹال ہو رہا ہے","ph_modrinth":"Modrinth تلاش...",
 "col_name":"نام","col_author":"مصنف","col_downloads":"ڈاؤن لوڈز","col_description":"تفصیل",
 "col_status":"اسٹیٹس","btn_open_folder":"فولڈر کھولیں","btn_clean":"خراب صاف کریں",
 "btn_toggle":"فعال/غیر فعال","btn_update_all":"سب اپڈیٹ کریں","st_installed":"✓ انسٹال شدہ",
 "st_enabled":"فعال","st_disabled":"غیر فعال",
 "msg_geyser":"Geyser کنفگ خودکار تبدیل ہو گئی!","msg_downloaded":"{fn} ڈاؤن لوڈ ہو گیا",
 "msg_update_hint":"دستی: پلگ اِن حذف کریں، پھر کیٹلاگ سے دوبارہ انسٹال کریں۔",
 "msg_clean":"{n} حذف ہوئے",
 # options
 "chk_whitelist":"وائٹ لسٹ","chk_cracked":"کریکڈ","chk_pvp":"پی وی پی","chk_flight":"اڑنے کی اجازت",
 "chk_cmdblocks":"کمانڈ بلاکس","chk_hardcore":"ہارڈکور","chk_nether":"نیڈر کی اجازت","lbl_motd":"پیغام (MOTD)",
 "sec_tunnel":"🌍 ٹنل","sec_bedrock":"📱 بیڈراک/PE","sec_world":"دنیا","sec_resources":"وسائل",
 "chk_bedrock":"بیڈراک فعال کریں (خودکار Geyser + Floodgate)","lbl_max_players":"زیادہ سے زیادہ کھلاڑی",
 "lbl_gamemode":"گیم موڈ","lbl_difficulty":"مشکل","lbl_viewdist":"نظر کا فاصلہ",
 "lbl_simdist":"نقل کا فاصلہ","lbl_spawnprot":"سپون تحفظ","lbl_max_ram":"زیادہ سے زیادہ رام",
 "lbl_custom_java":"کسٹم جاوا",
 # scheduler
 "ph_time":"گھنٹہ:منٹ","lbl_command":"کمانڈ",
 # networking / cloud / settings
 "net_info":"🌐 bore=ڈائنامک | 📌 serveo=فکسڈ (SSH) | 🎯 playit=رینڈم",
 "btn_install_bore":"bore انسٹال کریں (ڈائنامک)","btn_install_rclone":"rclone انسٹال کریں",
 "chk_enable":"فعال کریں","chk_auto_backup":"بند ہونے پر خودکار بیک اپ","rclone_ok":"rclone ✓","rclone_missing":"rclone ✗",
 "ginfo_pending":"🌍 جاوا گلوبل آ رہا ہے...",
 "chk_dictator":"ڈکٹیٹر فعال کریں","chk_manual":"دستی موڈ زبردستی","chk_start_win":"ونڈوز کے ساتھ شروع",
 "lbl_tunnel_default":"ڈیفالٹ ٹنل:","lbl_theme":"تھیم","theme_dark":"ڈارک","theme_light":"لائٹ",
 "lbl_language":"زبان","lang_en":"English","lang_ur":"اردو",
 # server detail
 "lbl_server":"سرور","lbl_local":"مقامی:","lbl_java":"جاوا:","lbl_bedrock":"بیڈراک:",
 "btn_dl_jar":"JAR ڈاؤن لوڈ","btn_dl_java":"جاوا ڈاؤن لوڈ","jar_ready":"JAR تیار","java_ready":"جاوا تیار",
 "eula_title":"EULA","eula_msg":"کیا Mojang EULA قبول ہے؟",
 # messages
 "err_error":"خرابی","err_invalid":"غلط","err_missing":"نہیں ملا","msg_saved":"محفوظ ہو گیا!",
 "msg_restored":"بحال ہو گیا!","msg_exists":"پہلے سے موجود ہے!","msg_failed":"ناکام!",
 "msg_stop_first":"پہلے سرور بند کریں!","confirm_delete":"کیا '{name}' حذف کریں؟",
 "msg_uploading":"اپ لوڈ ہو رہا ہے...","msg_installing":"انسٹال ہو رہا ہے...","msg_result":"نتیجہ",
 "msg_no_issues":"کوئی مسئلہ نہیں ملا","btn_latest":"تازہ ترین","btn_crashes":"کریشز","btn_analyze":"تجزیہ",
 "btn_up":"اوپر ⬆","msg_no_log":"کوئی لاگ فائل نہیں ملی","msg_no_crashes":"کوئی کریش رپورٹ نہیں",
 "iss_port":"پورٹ استعمال میں ہے","iss_java":"جاوا ورژن کا فرق","quit_title":"بند کریں","quit_msg":"سرور چل رہا ہے۔ کیا بند کریں؟",
 "jar_not_found":"JAR نہیں ملا","java_required":"جاوا {v} یا نئی درکار ہے",
 "locks_title":"لاک","locks_msg":"{n} لاک ملے۔ جاری رکھیں؟",
 "help_title":"مدد",
 "help_text":"AG CraftNode - مقامی Minecraft سرور منیجر۔\n\n• سرورز صفحے سے نیا سرور بنائیں\n• سرور صفحے سے شروع/بند کریں\n• پتہ دوستوں کو بھیجیں\n\nکلاؤڈ بیک اپ کے لیے rclone درکار ہے۔",
 # tools page
 "sec_tunnel_tools":"🌐 ٹنل ٹولز","sec_cloud":"☁ کلاؤڈ","sec_java":"☕ جاوا","sec_info":"📚 معلومات","sec_log":"لاگ",
 "btn_install_java":"جاوا انسٹال کریں","tool_ready":"✓ تیار","tool_na":"✗ دستیاب نہیں",
 "info_catalog":"کیٹلاگ میں کل پلگ اِنز: {n}\nپلگ اِنز ٹیب → 📚 کیٹلاگ",
 # dashboard stat labels
 "col_players":"کھلاڑی","col_uptime":"اپ ٹائم","col_ram":"رام",
 # misc
 "nav_back":"← سرورز","tunnel_off":"ٹنل بند",
 # activity
 "col_time":"وقت","col_server":"سرور","col_action":"کارروائی","col_details":"تفصیل",
 # networking
 "net_java_port":"جاوا پورٹ:","net_lan":"LAN IP:","net_bedrock_port":"بیڈراک پورٹ:","net_mode":"موڈ:",
 "net_status":"اسٹیٹس:","net_global":"جاوا گلوبل:","net_bedrock":"بیڈراک گلوبل:",
 # settings sections
 "sec_appearance":"ظاہری شکل","sec_dictator":"ٹنل ڈکٹیٹر","sec_startup":"سٹارٹ اپ",
}}

# ============ 250+ POPULAR PLUGINS CATALOG ============
POPULAR_PLUGINS = [
    # ===== BUILDING (30) =====
    ("WorldEdit","worldedit","Building","In-game map editor / schematics"),
    ("FastAsyncWorldEdit","fastasyncworldedit","Building","Async WorldEdit - super fast"),
    ("Axiom","axiom-paper","Building","Modern creative tools"),
    ("VoxelSniper","voxel-sniper","Building","Terrain sculpting"),
    ("Arceon","arceon","Building","Modern building toolkit"),
    ("WorldEditSelectionVisualizer","wesv","Building","Visualize WorldEdit selections"),
    ("Building Gadgets","building-gadgets","Building","Building tools"),
    ("CraftBook","craftbook","Building","Mechanisms and building"),
    ("Schematic Brush","schematicbrush","Building","Schematic brush tool"),
    ("BlockParty","blockparty","Building","Building minigame"),
    ("HolographicExtension","holographic-extension","Building","Hologram extensions"),
    ("GoBrush","gobrush","Building","Smooth terrain brush"),
    ("GoPaint","gopaint","Building","Paint terrain"),
    ("FastAsyncVoxelSniper","favs","Building","Fast voxel sniper"),
    ("Builder","builder","Building","Builder helper"),
    ("PlotSquared","plotsquared","Building","Creative plot worlds"),
    ("AsyncWorldEdit","asyncworldedit","Building","Async worldedit"),
    ("AreaShop","areashop","Building","Rent/sell regions"),
    ("RedProtect","redprotect","Building","Region protection"),
    ("ChestCommands","chestcommands","Building","GUI menus"),
    ("Holograms","holograms","Building","Hologram plugin"),
    ("ItemEdit","itemedit","Building","Edit item NBT"),
    ("NBTEditor","nbteditor","Building","NBT editor"),
    ("HeadDatabase","headdatabase","Building","Custom heads"),
    ("SkullCreator","skullcreator","Building","Custom skulls"),
    ("ArmorStandEditor","armorstandeditor","Building","Edit armor stands"),
    ("WeGo","wego","Building","WorldEdit companion"),
    ("FastAsyncSchematic","fas","Building","Fast schematics"),
    ("AsyncSchematic","asyncschematic","Building","Async schematic"),
    ("BuilderTools","buildertools","Building","Building utilities"),

    # ===== PROTECTION (25) =====
    ("WorldGuard","worldguard","Protection","Region protection"),
    ("GriefPrevention","griefprevention","Protection","Self-service claims"),
    ("CoreProtect","coreprotect","Protection","Block logging & rollback"),
    ("LuckPerms","luckperms","Protection","Permissions manager"),
    ("Towny","towny","Protection","Town/nation management"),
    ("GriefDefender","griefdefender","Protection","Advanced protection"),
    ("Residence","residence","Protection","Residence protection"),
    ("Lands","lands","Protection","Land claiming"),
    ("Factions","factions","Protection","Factions plugin"),
    ("SaberFactions","saberfactions","Protection","Factions fork"),
    ("ClaimChunk","claimchunk","Protection","Simple claims"),
    ("BentoBox","bentobox","Protection","Island protection"),
    ("LogBlock","logblock","Protection","Block logging"),
    ("Prism","prism","Protection","Block tracking"),
    ("HawkEye","hawkeye","Protection","Block logging"),
    ("AntiXRay","antixray","Protection","Anti-XRay protection"),
    ("Orebfuscator","orebfuscator","Protection","Ore obfuscation"),
    ("Vulcan","vulcan","Protection","Anti-cheat"),
    ("Matrix","matrix","Protection","Anti-cheat"),
    ("Spartan","spartan","Protection","Anti-cheat"),
    ("NoCheatPlus","nocheatplus","Protection","Anti-cheat"),
    ("GrimAC","grimac","Protection","Anti-cheat"),
    ("Themis","themis","Protection","Anti-cheat"),
    ("Negativity","negativity","Protection","Anti-cheat"),
    ("OpenInv","openinv","Protection","View player inventories"),

    # ===== ADMIN (30) =====
    ("EssentialsX","essentialsx","Admin","Essential commands"),
    ("EssentialsX Chat","essentialsx-chat","Admin","Chat formatting"),
    ("EssentialsX Spawn","essentialsx-spawn","Admin","Spawn management"),
    ("CMI","cmi","Admin","Complete admin suite"),
    ("Vault","vault","Admin","Economy/permission API"),
    ("CommandPanels","commandpanels","Admin","GUI command panels"),
    ("DeluxeMenus","deluxemenus","Admin","Menu creation"),
    ("ChestCommands","chestcommands","Admin","Chest menus"),
    ("GUIShop","guishop","Admin","GUI shop"),
    ("AdminCmd","admincmd","Admin","Admin commands"),
    ("ServerUtils","serverutils","Admin","Server utilities"),
    ("UltimateCore","ultimatecore","Admin","Admin tools"),
    ("CraftBook","craftbook-admin","Admin","Admin mechanisms"),
    ("CombatLog","combatlog","Admin","Combat logging"),
    ("SimpleBroadcast","simplebroadcast","Admin","Broadcast messages"),
    ("AutoBroadcaster","autobroadcaster","Admin","Auto broadcast"),
    ("ActionBar","actionbar","Admin","Actionbar messages"),
    ("BossBar","bossbar","Admin","Boss bar messages"),
    ("TitleManager","titlemanager","Admin","Titles & action bars"),
    ("EasyMotd","easymotd","Admin","MOTD management"),
    ("MotdChanger","motdchanger","Admin","MOTD change"),
    ("BanManager","banmanager","Admin","Advanced ban"),
    ("LiteBans","litebans","Admin","Bans & mutes"),
    ("AdvancedBan","advancedban","Admin","Advanced punishment"),
    ("MaxBans","maxbans","Admin","Ban system"),
    ("AnarchyExploitFixes","anarchyexploitfixes","Admin","Anarchy fixes"),
    ("ServerListPlus","serverlistplus","Admin","Server list customization"),
    ("PlayerServers","playerservers","Admin","Player servers"),
    ("VotingPlugin","votingplugin","Admin","Voting rewards"),
    ("NuVotifier","nuvotifier","Admin","Vote listener"),

    # ===== PERFORMANCE (20) =====
    ("Chunky","chunky","Performance","Pregenerate chunks"),
    ("Spark","spark","Performance","Performance profiler"),
    ("ClearLag","clearlag","Performance","Remove lag-causing entities"),
    ("FarmLimiter","farm-limiter","Performance","Limit mob farms"),
    ("EntityTrackerFixer","entitytrackerfixer","Performance","Fix entity tracking"),
    ("LagAssist","lagassist","Performance","Lag prevention"),
    ("Insights","insights","Performance","Server analytics"),
    ("Plan","plan","Performance","Player analytics"),
    ("MorePaperLib","morepaperlib","Performance","Paper library"),
    ("FastAsyncChunkGen","fastasyncchunkgen","Performance","Fast chunk gen"),
    ("ServerBooster","serverbooster","Performance","Server optimization"),
    ("AntiLag","antilag","Performance","Reduce lag"),
    ("LagMonitor","lagmonitor","Performance","Monitor lag"),
    ("AntiXrayHeuristics","antixrayheuristics","Performance","Xray detection"),
    ("ChunkLoader","chunkloader","Performance","Chunk loaders"),
    ("AntiCrash","anticrash","Performance","Crash prevention"),
    ("BookLimiter","booklimiter","Performance","Limit books"),
    ("ItemLimiter","itemlimiter","Performance","Limit items"),
    ("EntityLimiter","entitylimiter","Performance","Limit entities"),
    ("PandaWire","pandawire","Performance","Redstone optimization"),

    # ===== COMPATIBILITY (12) =====
    ("ViaVersion","viaversion","Compatibility","Allow newer clients"),
    ("ViaBackwards","viabackwards","Compatibility","Allow older clients"),
    ("ViaRewind","viarewind","Compatibility","1.7-1.8 support"),
    ("ProtocolLib","protocollib","Compatibility","Packet manipulation"),
    ("ProtocolSupport","protocolsupport","Compatibility","Multi-version"),
    ("ViaProxy","viaproxy","Compatibility","Proxy compatibility"),
    ("PacketEvents","packetevents","Compatibility","Packet library"),
    ("PacketLimiter","packetlimiter","Compatibility","Limit packets"),
    ("ClientCatcher","clientcatcher","Compatibility","Client info"),
    ("VersionSupport","versionsupport","Compatibility","Version compat"),
    ("Geyser-Spigot","geyser","Compatibility","Bedrock support"),
    ("Floodgate","floodgate","Compatibility","Bedrock auth"),

    # ===== BEDROCK/PE (5) =====
    ("GeyserMC","geyser","Bedrock","Bedrock Edition support"),
    ("Floodgate","floodgate","Bedrock","Bedrock authentication"),
    ("GeyserExtras","geyserextras","Bedrock","Geyser extensions"),
    ("FloodgateSkinUploader","floodgateskinuploader","Bedrock","Bedrock skins"),
    ("BedrockBridge","bedrockbridge","Bedrock","Bedrock bridge"),

    # ===== WEB/MAPS (10) =====
    ("Dynmap","dynmap","Web","Live web map"),
    ("BlueMap","bluemap","Web","3D web map"),
    ("Squaremap","squaremap","Web","Lightweight web map"),
    ("Pl3xMap","pl3xmap","Web","Modern web map"),
    ("Overviewer","overviewer","Web","Map renderer"),
    ("Dynmap-Regions","dynmap-regions","Web","Dynmap regions"),
    ("Dynmap-Countries","dynmap-countries","Web","Dynmap countries"),
    ("LiveAtlas","liveatlas","Web","Live atlas"),
    ("DiscordSRV","discordsrv","Web","Discord bridge"),
    ("WebConsole","webconsole","Web","Web console"),

    # ===== WORLDS (15) =====
    ("Multiverse-Core","multiverse-core","Worlds","Multi-world"),
    ("Multiverse-Portals","multiverse-portals","Worlds","Portals"),
    ("Multiverse-NetherPortals","multiverse-netherportals","Worlds","Nether portals"),
    ("Multiverse-Inventories","multiverse-inventories","Worlds","Multi inventories"),
    ("MyWorlds","myworlds","Worlds","World management"),
    ("WorldManager","worldmanager","Worlds","World management"),
    ("Worlds","worlds","Worlds","World plugin"),
    ("BetterPortals","betterportals","Worlds","Better portals"),
    ("PortalNetwork","portalnetwork","Worlds","Portal network"),
    ("WorldBorder","worldborder","Worlds","World border"),
    ("BorderManager","bordermanager","Worlds","Border management"),
    ("MultiWorld","multiworld","Worlds","Multiple worlds"),
    ("WorldGuardExtraFlags","worldguardextraflags","Worlds","WGExtraFlags"),
    ("Skyblock","skyblock","Worlds","Skyblock"),
    ("AcidIsland","acidisland","Worlds","Acid island"),

    # ===== GAMEPLAY (40) =====
    ("Jobs Reborn","jobs","Gameplay","Job system"),
    ("Shopkeepers","shopkeepers","Gameplay","Villager shops"),
    ("mcMMO","mcmmo","Gameplay","RPG skill leveling"),
    ("Aurelium Skills","aurelium-skills","Gameplay","Modern RPG skills"),
    ("BetonQuest","betonquest","Gameplay","Quest engine"),
    ("MythicMobs","mythicmobs","Gameplay","Custom mobs"),
    ("EliteMobs","elitemobs","Gameplay","Custom bosses"),
    ("LevelledMobs","levelledmobs","Gameplay","Leveled mobs"),
    ("QuestWorlds","questworlds","Gameplay","Quests"),
    ("BeautyQuests","beautyquests","Gameplay","Quest system"),
    ("Heroes","heroes","Gameplay","RPG classes"),
    ("SkillsPro","skillspro","Gameplay","Skill system"),
    ("RPGmechanics","rpgmechanics","Gameplay","RPG mechanics"),
    ("CustomCrafting","customcrafting","Gameplay","Custom recipes"),
    ("RecipeManager","recipemanager","Gameplay","Recipe editor"),
    ("ItemsAdder","itemsadder","Gameplay","Custom items"),
    ("Oraxen","oraxen","Gameplay","Custom items"),
    ("MythicDrops","mythicdrops","Gameplay","Custom drops"),
    ("LevelledMobs","levelledmobs2","Gameplay","Level mobs"),
    ("DropEdit","dropedit","Gameplay","Drop editor"),
    ("AutoSell","autosell","Gameplay","Auto sell"),
    ("SellAll","sellall","Gameplay","Sell items"),
    ("ChestShop","chestshop","Gameplay","Chest shops"),
    ("PlayerShops","playershops","Gameplay","Player shops"),
    ("MarriageMaster","marriagemaster","Gameplay","Marriage plugin"),
    ("Pets","pets","Gameplay","Pet system"),
    ("Minions","minions","Gameplay","Minion system"),
    ("IslandBorder","islandborder","Gameplay","Island borders"),
    ("Slimefun","slimefun","Gameplay","Tech/magic addon"),
    ("Slimefun4","slimefun4","Gameplay","Slimefun"),
    ("Brewery","brewery","Gameplay","Brewing plugin"),
    ("BreweryX","breweryx","Gameplay","Brewery fork"),
    ("BossBarTimer","bossbartimer","Gameplay","Boss bar timer"),
    ("BattleRoyale","battleroyale","Gameplay","Battle royale"),
    ("BedWars1058","bedwars1058","Gameplay","BedWars"),
    ("BedWarsProxy","bedwarsproxy","Gameplay","BedWars proxy"),
    ("SkyWars","skywars","Gameplay","SkyWars"),
    ("BuildBattle","buildbattle","Gameplay","Build battle"),
    ("Parkour","parkour","Gameplay","Parkour plugin"),
    ("MiniGames","minigames","Gameplay","Minigames"),
    ("MurderMystery","murdermystery","Gameplay","Murder mystery"),

    # ===== ECONOMY (15) =====
    ("EssentialsX Economy","essentialsx","Economy","Basic economy"),
    ("Vault","vault","Economy","Economy API"),
    ("ShopGUIPlus","shopguiplus","Economy","GUI shop"),
    ("AuctionHouse","auctionhouse","Economy","Player auctions"),
    ("AuctionMaster","auctionmaster","Economy","Auctions"),
    ("Bazaar","bazaar","Economy","Bazaar system"),
    ("EconomyShopGUI","economyshopgui","Economy","Economy shops"),
    ("iConomy","iconomy","Economy","Old economy"),
    ("CMI Economy","cmi","Economy","CMI economy"),
    ("PlayerPoints","playerpoints","Economy","Points system"),
    ("TokenManager","tokenmanager","Economy","Token system"),
    ("TokenEnchant","tokenenchant","Economy","Enchant tokens"),
    ("GemsEconomy","gemseconomy","Economy","Multi-currency"),
    ("TNE","tne","Economy","The New Economy"),
    ("Coins","coins","Economy","Coins plugin"),

    # ===== CHAT (20) =====
    ("PlaceholderAPI","placeholderapi","Chat","Placeholder system"),
    ("TAB","tab-was-taken","Chat","Tab list"),
    ("VentureChat","venturechat","Chat","Advanced chat"),
    ("EssentialsX Chat","essentialsx-chat","Chat","Chat formatting"),
    ("ChatControl","chatcontrol","Chat","Chat management"),
    ("ChatControlRed","chatcontrolred","Chat","Chat filter"),
    ("DeluxeChat","deluxechat","Chat","Deluxe chat"),
    ("ChatManager","chatmanager","Chat","Chat manager"),
    ("ChatEx","chatex","Chat","Chat extensions"),
    ("InteractiveChat","interactivechat","Chat","Clickable chat"),
    ("MiniPlaceholders","miniplaceholders","Chat","Mini placeholders"),
    ("ChatItem","chatitem","Chat","Show items in chat"),
    ("DiscordChat","discordchat","Chat","Discord bridge"),
    ("TrChat","trchat","Chat","Chat plugin"),
    ("CarbonChat","carbonchat","Chat","Chat plugin"),
    ("PaperChat","paperchat","Chat","Paper chat"),
    ("HeroChat","herochat","Chat","Hero chat"),
    ("LunaChat","lunachat","Chat","Luna chat"),
    ("ChatSentinel","chatsentinel","Chat","Chat filter"),
    ("GlobalChat","globalchat","Chat","Global chat"),

    # ===== HOLOGRAMS/NPCs (10) =====
    ("DecentHolograms","decentholograms","Holograms","Holograms"),
    ("Holographic Displays","holographic-displays","Holograms","Classic holograms"),
    ("HolographicDisplays","holographicdisplays","Holograms","Holograms"),
    ("FancyHolograms","fancyholograms","Holograms","Fancy holograms"),
    ("Citizens","citizens","NPCs","NPC API"),
    ("ZNPCsPlus","znpcsplus","NPCs","ZNPCs+"),
    ("FancyNPCs","fancynpcs","NPCs","Fancy NPCs"),
    ("Sentinel","sentinel","NPCs","NPC combat"),
    ("Denizen","denizen","NPCs","Script engine"),
    ("BossShopPro","bossshoppro","NPCs","Shop NPCs"),

    # ===== SECURITY/AUTH (10) =====
    ("AuthMeReloaded","authmereloaded","Security","Login/register"),
    ("nLogin","nlogin","Security","Auth system"),
    ("LibreLogin","librelogin","Security","Login system"),
    ("FastLogin","fastlogin","Security","Fast login"),
    ("JPremium","jpremium","Security","Premium auth"),
    ("LoginSecurity","loginsecurity","Security","Login security"),
    ("AuthMe","authme","Security","Auth"),
    ("CrazyLogin","crazylogin","Security","Crazy login"),
    ("UltimateAuth","ultimateauth","Security","Auth plugin"),
    ("SimpleAuth","simpleauth","Security","Simple auth"),

    # ===== MISC (25) =====
    ("Trees","trees","Misc","Custom trees"),
    ("TreeAssist","treeassist","Misc","Tree felling"),
    ("Timber","timber","Misc","Chop trees"),
    ("VeinMiner","veinminer","Misc","Mine veins"),
    ("AutoPickup","autopickup","Misc","Auto pickup items"),
    ("SilkSpawners","silkspawners","Misc","Silk touch spawners"),
    ("PickupArrows","pickuparrows","Misc","Pickup arrows"),
    ("CombatLogX","combatlogx","Misc","Combat log"),
    ("DeathMessages","deathmessages","Misc","Custom death messages"),
    ("DeathCoordinates","deathcoordinates","Misc","Death coords"),
    ("GravesX","gravesx","Misc","Player graves"),
    ("Gravestones","gravestones","Misc","Grave stones"),
    ("NoDeathDrops","nodeathdrops","Misc","No drops on death"),
    ("KeepInventory","keepinventory","Misc","Keep inventory"),
    ("StackMob","stackmob","Misc","Stack mobs"),
    ("Stacker","stacker","Misc","Stack entities"),
    ("WildStacker","wildstacker","Misc","Stack mobs/items"),
    ("EzRTP","ezrtp","Misc","Random teleport"),
    ("BetterRTP","betterrtp","Misc","RTP plugin"),
    ("RandomTP","randomtp","Misc","Random teleport"),
    ("ServerSigns","serversigns","Misc","Command signs"),
    ("HolographicSkins","holographicskins","Misc","Hologram skins"),
    ("PhotoParty","photoparty","Misc","Photo booth"),
    ("WorldEditCUI","worldeditcui","Misc","WorldEdit UI"),
    ("NameTagChanger","nametagchanger","Misc","Name tag editor"),
    ("UltimateChest","ultimatechest","Misc","Chest system"),
]

print(f"Total plugins in catalog: {len(POPULAR_PLUGINS)}")

def load_json(p,d):
    if os.path.exists(p):
        try:
            with open(p,"r",encoding="utf-8") as f: return json.load(f)
        except: return d
    return d
def save_json(p,d):
    with open(p,"w",encoding="utf-8") as f: json.dump(d,f,indent=4,ensure_ascii=False)
def load_servers(): return load_json(DATA_FILE,[])
def save_servers(s): save_json(DATA_FILE,s)
def load_config():
    c=load_json(CONFIG_FILE,{})
    d={"theme":"dark","language":"en","cloud_enabled":False,"cloud_remote":"gdrive","cloud_folder":"AGCraftNode_Backups",
       "auto_backup_on_stop":True,"dictator_enabled":True,"start_with_windows":False,
       "auto_tunnel_on_start":True,"default_tunnel_provider":"bore","manual_mode":False}
    for k,v in d.items():
        if k not in c: c[k]=v
    return c
def save_config(c): save_json(CONFIG_FILE,c)
def log_activity(a,sn,det=""):
    x=load_json(ACTIVITY_FILE,[])
    x.insert(0,{"time":datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"server":sn,"action":a,"details":det})
    save_json(ACTIVITY_FILE,x[:500])
def get_local_ip():
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect(("8.8.8.8",80))
        ip=s.getsockname()[0]; s.close(); return ip
    except: return "127.0.0.1"
def get_next_port():
    u=[int(s.get("port",25565)) for s in load_servers()]; p=25565
    while p in u: p+=1
    return str(p)
def tools_dir():
    os.makedirs(TOOLS_DIR,exist_ok=True); return os.path.abspath(TOOLS_DIR)
def find_tool(name):
    local = os.path.join(tools_dir(), name + (".exe" if os.name=='nt' else ""))
    if os.path.exists(local): return local
    return shutil.which(name)
def download_file(url, dest, progress_cb=None):
    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=300) as r:
            total = int(r.headers.get('content-length', 0)); dl = 0
            with open(dest, 'wb') as f:
                while True:
                    c = r.read(65536)
                    if not c: break
                    f.write(c); dl += len(c)
                    if progress_cb and total > 0: progress_cb(int(dl/total*100))
        return True
    except Exception as e:
        print(f"Download error: {e}"); return False
def random_name(n=8):
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=n))

def detect_worlds(sd):
    pr=load_props(sd); ln=pr.get("level-name","world"); ws=[]; seen=set()
    for suf,typ in [("","Overworld"),("_nether","Nether"),("_the_end","The End")]:
        wn=ln+suf; wp=os.path.join(sd,wn)
        if os.path.exists(wp) and os.path.isdir(wp):
            has_data = (os.path.exists(os.path.join(wp,"level.dat")) or 
                       os.path.exists(os.path.join(wp,"region")) or 
                       os.path.exists(os.path.join(wp,"DIM-1")) or 
                       os.path.exists(os.path.join(wp,"DIM1")) or
                       os.path.exists(os.path.join(wp,"data")))
            if has_data:
                ws.append({"name":wn,"path":wp,"type":typ}); seen.add(wn)
    base=os.path.join(sd,ln)
    if os.path.exists(base):
        for dim,typ in [("DIM-1","Nether"),("DIM1","The End")]:
            dp=os.path.join(base,dim)
            if os.path.exists(dp) and os.path.isdir(dp):
                key = f"{ln}/{dim}"
                if key not in seen:
                    ws.append({"name":key,"path":dp,"type":typ}); seen.add(key)
        for sub,typ in [("nether","Nether"),("the_end","The End"),("the_nether","Nether")]:
            dp=os.path.join(base,sub)
            if os.path.exists(dp) and os.path.isdir(dp):
                key = f"{ln}/{sub}"
                if key not in seen:
                    ws.append({"name":key,"path":dp,"type":typ}); seen.add(key)
    if os.path.exists(sd):
        for item in os.listdir(sd):
            ip = os.path.join(sd, item)
            if os.path.isdir(ip) and item not in seen:
                if item.endswith(("_nether","_the_end")): continue
                if item in (".", "..", "logs", "plugins", "config", "cache", "libraries", "versions"):
                    continue
                if os.path.exists(os.path.join(ip,"level.dat")):
                    if not any(item == w["name"] for w in ws):
                        ws.append({"name":item,"path":ip,"type":"Custom"})
    return ws

def edit_geyser_config(sd, bedrock_port="19132"):
    configs = [
        os.path.join(sd, "plugins", "Geyser-Spigot", "config.yml"),
        os.path.join(sd, "plugins", "Geyser", "config.yml"),
    ]
    edited = 0
    for gc in configs:
        if not os.path.exists(gc): continue
        try:
            with open(gc, "r", encoding="utf-8") as f: content = f.read()
            content = re.sub(r'(\n\s+port:\s*)\d+', f'\\g<1>{bedrock_port}', content, count=1)
            if "above-bedrock-nether-building" in content:
                content = re.sub(r'above-bedrock-nether-building:\s*\w+', 'above-bedrock-nether-building: true', content)
            else:
                content = re.sub(r'(gameplay:\s*\n)', r'\1  above-bedrock-nether-building: true\n', content, count=1)
            if "auth-type:" in content:
                content = re.sub(r'(auth-type:\s*)\w+', r'\1floodgate', content)
            if "command-suggestions" in content:
                content = re.sub(r'command-suggestions:\s*\w+', 'command-suggestions: true', content)
            with open(gc, "w", encoding="utf-8") as f: f.write(content)
            edited += 1
        except Exception as e:
            print(f"Geyser config edit error: {e}")
    return edited

class BoreDictator(QObject):
    log = pyqtSignal(str); address_found = pyqtSignal(str, str); status_changed = pyqtSignal(str)
    def __init__(self):
        super().__init__(); self.process = None
    def is_installed(self): return find_tool("bore") is not None
    def start(self, local_port):
        if not self.is_installed(): self.log.emit("Bore install nahi"); return False
        if self.process and self.process.state()==QProcess.ProcessState.Running: return True
        p=find_tool("bore"); self.process=QProcess()
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.process.readyReadStandardOutput.connect(self._on_output)
        self.process.start(p, ["local", str(local_port), "--to", "bore.pub"])
        self.log.emit(f"Bore (Dynamic): port {local_port}")
        return True
    def _on_output(self):
        if not self.process: return
        data=self.process.readAllStandardOutput().data().decode('utf-8',errors='ignore')
        if not data: return
        for line in data.strip().split("\n"):
            if not line.strip(): continue
            self.log.emit(line.strip())
            m=re.search(r'listening at ([a-z0-9.-]+):(\d+)',line,re.IGNORECASE)
            if m: self.address_found.emit(m.group(1),m.group(2))
    def stop(self):
        if self.process: self.process.kill(); self.process.waitForFinished(2000); self.process=None

class ServeoDictator(QObject):
    log = pyqtSignal(str); address_found = pyqtSignal(str, str); status_changed = pyqtSignal(str)
    def __init__(self):
        super().__init__(); self.process=None; self.subdomain=None; self.port=None
    def is_installed(self): return shutil.which("ssh") is not None
    def start(self, local_port, subdomain):
        if not self.is_installed(): self.log.emit("SSH client nahi"); return False
        if self.process and self.process.state()==QProcess.ProcessState.Running: return True
        self.subdomain=subdomain; self.port=local_port
        ssh_exe=shutil.which("ssh") or "ssh"
        self.process=QProcess()
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.process.readyReadStandardOutput.connect(self._on_output)
        args=["-o","StrictHostKeyChecking=no","-o","ServerAliveInterval=30",
              "-R",f"{subdomain}:{local_port}:localhost:{local_port}","serveo.net"]
        self.process.start(ssh_exe,args)
        self.log.emit(f"Serveo (Fixed): {subdomain}.serveo.net:{local_port}")
        return True
    def _on_output(self):
        if not self.process: return
        data=self.process.readAllStandardOutput().data().decode('utf-8',errors='ignore')
        if not data: return
        for line in data.strip().split("\n"):
            if not line.strip(): continue
            self.log.emit(line.strip())
            if "Forwarding" in line or "serveo.net" in line.lower():
                if self.subdomain: self.address_found.emit(f"{self.subdomain}.serveo.net",str(self.port))
    def stop(self):
        if self.process:
            try: self.process.kill(); self.process.waitForFinished(2000)
            except: pass
            self.process=None

class PlayitDictator(QObject):
    log = pyqtSignal(str); address_found = pyqtSignal(str); status_changed = pyqtSignal(str); needs_manual = pyqtSignal()
    def __init__(self): super().__init__(); self.process=None; self.address=None
    def is_installed(self): return find_tool("playit") is not None
    def start(self):
        if not self.is_installed(): return False
        if self.process and self.process.state()==QProcess.ProcessState.Running: return True
        p=find_tool("playit"); self.process=QProcess()
        self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.process.readyReadStandardOutput.connect(self._on_output)
        self.process.setWorkingDirectory(tools_dir())
        self.process.start(p,[]); self.log.emit("playit starting...")
        return True
    def _on_output(self):
        if not self.process: return
        data=self.process.readAllStandardOutput().data().decode('utf-8',errors='ignore')
        if not data: return
        for line in data.strip().split("\n"):
            if not line.strip(): continue
            self.log.emit(line.strip())
            m=re.search(r'(https://playit\.gg/claim/[a-zA-Z0-9-]+)',line)
            if m:
                try: webbrowser.open(m.group(1))
                except: pass
                self.status_changed.emit("needs_setup"); continue
            if "Waiting for frontend" in line: self.needs_manual.emit(); continue
            m=re.search(r'\b([a-z]+-[a-z]+-\d+\.(?:playit\.gg|at\.playit\.gg|auto\.playit\.gg))\b',line,re.IGNORECASE)
            if m: self.address=m.group(1); self.address_found.emit(self.address); continue
            m=re.search(r'\b([a-z0-9-]+\.joinmc\.link)\b',line,re.IGNORECASE)
            if m: self.address=m.group(1); self.address_found.emit(self.address)
    def stop(self):
        if self.process: self.process.kill(); self.process.waitForFinished(2000); self.process=None

class BoreInstaller(QThread):
    progress=pyqtSignal(int); log=pyqtSignal(str); finished=pyqtSignal(bool,str)
    def run(self):
        try:
            osn=platform.system().lower()
            if osn=="windows":
                url="https://github.com/ekzhang/bore/releases/download/v0.5.1/bore-v0.5.1-x86_64-pc-windows-msvc.zip"
                zp=os.path.join(tools_dir(),"bore.zip")
                if not download_file(url,zp,self.progress.emit): self.finished.emit(False,"Failed"); return
                with zipfile.ZipFile(zp,'r') as z:
                    for m in z.namelist():
                        if m.endswith("bore.exe"):
                            with z.open(m) as src, open(os.path.join(tools_dir(),"bore.exe"),"wb") as dst:
                                shutil.copyfileobj(src,dst)
                os.remove(zp)
            elif osn=="linux":
                url="https://github.com/ekzhang/bore/releases/download/v0.5.1/bore-v0.5.1-x86_64-unknown-linux-musl.tar.gz"
                import tarfile
                zp=os.path.join(tools_dir(),"bore.tgz")
                if not download_file(url,zp,self.progress.emit): self.finished.emit(False,"Failed"); return
                with tarfile.open(zp) as t: t.extractall(tools_dir())
                os.remove(zp); os.chmod(os.path.join(tools_dir(),"bore"),0o755)
            else: self.finished.emit(False,"macOS: brew install bore-cli"); return
            self.finished.emit(True,"Bore ready!")
        except Exception as e: self.finished.emit(False,str(e))

class RcloneInstaller(QThread):
    progress=pyqtSignal(int); log=pyqtSignal(str); finished=pyqtSignal(bool,str)
    def run(self):
        try:
            osn=platform.system().lower(); arch="amd64" if platform.machine().endswith('64') else "386"
            if osn=="windows":
                url=f"https://downloads.rclone.org/rclone-current-windows-{arch}.zip"
                zp=os.path.join(tools_dir(),"rclone.zip")
                if not download_file(url,zp,self.progress.emit): self.finished.emit(False,"Failed"); return
                with zipfile.ZipFile(zp,'r') as z:
                    for m in z.namelist():
                        if m.endswith("rclone.exe"):
                            with z.open(m) as src, open(os.path.join(tools_dir(),"rclone.exe"),"wb") as dst:
                                shutil.copyfileobj(src,dst)
                os.remove(zp)
            elif osn=="linux":
                url=f"https://downloads.rclone.org/rclone-current-linux-{arch}.zip"
                zp=os.path.join(tools_dir(),"rclone.zip")
                if not download_file(url,zp,self.progress.emit): self.finished.emit(False,"Failed"); return
                with zipfile.ZipFile(zp,'r') as z:
                    for m in z.namelist():
                        if m.endswith("/rclone"):
                            with z.open(m) as src, open(os.path.join(tools_dir(),"rclone"),"wb") as dst:
                                shutil.copyfileobj(src,dst)
                            os.chmod(os.path.join(tools_dir(),"rclone"),0o755)
                os.remove(zp)
            else: self.finished.emit(False,"macOS"); return
            self.finished.emit(True,"rclone ready!")
        except Exception as e: self.finished.emit(False,str(e))

class JavaInstaller(QThread):
    progress=pyqtSignal(int); log=pyqtSignal(str); finished=pyqtSignal(bool,str)
    def __init__(self,major=REQUIRED_JAVA): super().__init__(); self.major=major
    def run(self):
        try:
            osn=platform.system().lower()
            pl="windows" if osn=="windows" else ("linux" if osn=="linux" else "mac")
            url=f"https://api.adoptium.net/v3/binary/latest/{self.major}/ga/{pl}/x64/jre/hotspot/normal/eclipse"
            os.makedirs(JAVA_DIR,exist_ok=True); zp=os.path.join(JAVA_DIR,f"j{self.major}.zip")
            if not download_file(url,zp,self.progress.emit): self.finished.emit(False,"Failed"); return
            with zipfile.ZipFile(zp,'r') as z: z.extractall(JAVA_DIR)
            os.remove(zp); self.finished.emit(True,f"Java {self.major} ready!")
        except Exception as e: self.finished.emit(False,str(e))

def find_local_java(mv=REQUIRED_JAVA):
    base=os.path.abspath(JAVA_DIR)
    if not os.path.exists(base): return None
    exe="java.exe" if os.name=='nt' else "java"
    cands=[os.path.join(r,exe) for r,d,fs in os.walk(base) if exe in fs]
    pref=[p for p in cands if any(f"jdk-{v}" in p.lower() for v in [25,26,27])]
    for p in pref+[c for c in cands if c not in pref]:
        try:
            cf=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
            r=subprocess.run([p,"-version"],capture_output=True,text=True,timeout=10,creationflags=cf)
            m=re.search(r'version "(?:1\.)?(\d+)',(r.stderr or r.stdout).lower())
            if m and int(m.group(1))>=mv: return p
        except: continue
    return None
def find_system_java(mv=REQUIRED_JAVA):
    p=shutil.which("java")
    if not p: return None
    try:
        cf=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
        r=subprocess.run([p,"-version"],capture_output=True,text=True,timeout=10,creationflags=cf)
        m=re.search(r'version "(?:1\.)?(\d+)',(r.stderr or r.stdout).lower())
        return p if m and int(m.group(1))>=mv else None
    except: return None
def find_java(mv=REQUIRED_JAVA): return find_local_java(mv) or find_system_java(mv)

def auto_kill_java(agg=False):
    k=0
    if os.name!='nt': return k
    try:
        ps=("Get-CimInstance Win32_Process -Filter \"name='java.exe'\" | Where-Object { $_.CommandLine -like '*server.jar*' } | Select-Object -ExpandProperty ProcessId")
        r=subprocess.run(["powershell","-NoProfile","-NonInteractive","-Command",ps],capture_output=True,text=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW,encoding='utf-8',errors='ignore')
        for pid in [l.strip() for l in (r.stdout or "").strip().split("\n") if l.strip().isdigit()]:
            try: subprocess.run(["taskkill","/F","/T","/PID",pid],capture_output=True,timeout=8,creationflags=subprocess.CREATE_NO_WINDOW); k+=1
            except: pass
    except: pass
    if agg or k==0:
        try:
            r=subprocess.run(["taskkill","/F","/IM","java.exe"],capture_output=True,timeout=15,creationflags=subprocess.CREATE_NO_WINDOW)
            if r.returncode==0: k=max(k,1)
        except: pass
    return k
def force_remove(p):
    if not os.path.exists(p): return True
    for _ in range(10):
        try: os.remove(p); return True
        except PermissionError: time.sleep(0.4)
        except: break
    try:
        tr=p+f".del{int(time.time())}"; os.rename(p,tr); time.sleep(0.1)
        try: os.remove(tr)
        except: pass
        return True
    except: return False
def auto_fix_locks(sd):
    rm=0
    for r,d,fs in os.walk(sd):
        for fn in fs:
            if fn=="session.lock":
                if force_remove(os.path.join(r,fn)): rm+=1
    rem=[os.path.join(r,fn) for r,d,fs in os.walk(sd) for fn in fs if fn=="session.lock"]
    if rem:
        auto_kill_java(True); time.sleep(2)
        for p in rem:
            if force_remove(p): rm+=1
    st=sum(1 for r,d,fs in os.walk(sd) for fn in fs if fn=="session.lock")
    lf=os.path.join(sd,"logs","latest.log")
    if os.path.exists(lf): force_remove(lf)
    return rm,st
def auto_clean_plugins(sd):
    pd=os.path.join(sd,"plugins")
    if not os.path.exists(pd): return 0
    n=0
    for f in os.listdir(pd):
        if f.endswith(".jar"):
            fp=os.path.join(pd,f)
            try:
                if os.path.getsize(fp)<10240 or not zipfile.is_zipfile(fp):
                    os.remove(fp); n+=1
            except:
                try: os.remove(fp); n+=1
                except: pass
    return n
def auto_pre_start(sd, log_cb=None):
    k=auto_kill_java(False)
    if k and log_cb: log_cb(f"Auto-fix: Killed {k} Java process(es)")
    time.sleep(1.2)
    r,l=auto_fix_locks(sd)
    if r and log_cb: log_cb(f"Auto-fix: Removed {r} session.lock(s)")
    if l and log_cb: log_cb(f"Auto-fix: WARN {l} lock(s) remain")
    c=auto_clean_plugins(sd)
    if c and log_cb: log_cb(f"Auto-fix: Removed {c} corrupted plugin(s)")
    return l
def get_dir_size(p):
    t=0
    try:
        for r,d,fs in os.walk(p):
            for f in fs:
                try: t+=os.path.getsize(os.path.join(r,f))
                except: pass
    except: pass
    return t
def human_size(b):
    for u in ['B','KB','MB','GB','TB']:
        if b<1024: return f"{b:.1f} {u}"
        b/=1024
    return f"{b:.1f} PB"
def load_props(sd):
    pr={}
    p=os.path.join(sd,"server.properties")
    if os.path.exists(p):
        with open(p,"r",encoding="utf-8") as f:
            for ln in f:
                ln=ln.strip()
                if "=" in ln and not ln.startswith("#"):
                    k,v=ln.split("=",1); pr[k]=v
    return pr
def save_props(sd,pr):
    p=os.path.join(sd,"server.properties")
    with open(p,"w",encoding="utf-8") as f:
        f.write("#Minecraft server properties\n")
        for k,v in pr.items(): f.write(f"{k}={v}\n")
def write_eula(sd):
    try:
        with open(os.path.join(sd,"eula.txt"),"w") as f: f.write("eula=true\n")
        return True
    except: return False
def read_sj(sd,fn):
    p=os.path.join(sd,fn)
    if not os.path.exists(p): return []
    try:
        with open(p,"r",encoding="utf-8") as f: return json.load(f) or []
    except: return []
def rclone_available(): return find_tool("rclone") is not None
def playit_available(): return find_tool("playit") is not None
def bore_available(): return find_tool("bore") is not None
def serveo_available(): return shutil.which("ssh") is not None

class RcloneUpload(QThread):
    finished=pyqtSignal(bool,str)
    def __init__(self,lp,rem,rp): super().__init__(); self.lp=lp; self.rem=rem; self.rp=rp
    def run(self):
        try:
            rc=find_tool("rclone")
            if not rc: self.finished.emit(False,"rclone missing"); return
            p=subprocess.run([rc,"copy",self.lp,f"{self.rem}:{self.rp}","-P","--stats-one-line"],
                           capture_output=True,text=True,timeout=3600)
            self.finished.emit(p.returncode==0,"Done" if p.returncode==0 else p.stderr[:500])
        except Exception as e: self.finished.emit(False,str(e))

class PaperDownloader(QThread):
    progress=pyqtSignal(int); finished=pyqtSignal(bool,str)
    def __init__(self,sd,v="latest"): super().__init__(); self.sd=sd; self.v=v
    def run(self):
        try:
            if self.v=="latest":
                req=urllib.request.Request("https://fill.papermc.io/v3/projects/paper",headers={"User-Agent":USER_AGENT})
                with urllib.request.urlopen(req) as r:
                    d=json.loads(r.read().decode()); vs=[x for g in d.get("versions",{}).values() for x in g]
                tv=None
                for x in vs:
                    try:
                        u=f"https://fill.papermc.io/v3/projects/paper/versions/{x}/builds/latest"
                        req=urllib.request.Request(u,headers={"User-Agent":USER_AGENT})
                        with urllib.request.urlopen(req) as r:
                            b=json.loads(r.read().decode())
                            if b.get("channel")=="STABLE": tv=x; break
                    except: continue
                if not tv: self.finished.emit(False,"No stable"); return
            else: tv=self.v
            u=f"https://fill.papermc.io/v3/projects/paper/versions/{tv}/builds/latest"
            req=urllib.request.Request(u,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req) as r:
                b=json.loads(r.read().decode()); url=b["downloads"]["server:default"]["url"]
            dest=os.path.join(self.sd,"server.jar")
            req=urllib.request.Request(url,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req) as r:
                total=int(r.headers.get('content-length',0)); dl=0
                with open(dest,'wb') as f:
                    while True:
                        c=r.read(8192)
                        if not c: break
                        f.write(c); dl+=len(c)
                        if total: self.progress.emit(int(dl/total*100))
            self.finished.emit(True,f"Paper {tv}!")
        except Exception as e: self.finished.emit(False,str(e))
class PurpurDownloader(QThread):
    progress=pyqtSignal(int); finished=pyqtSignal(bool,str)
    def __init__(self,sd,v="latest"): super().__init__(); self.sd=sd; self.v=v
    def run(self):
        try:
            if self.v=="latest":
                req=urllib.request.Request("https://api.purpurmc.org/v2/purpur",headers={"User-Agent":USER_AGENT})
                with urllib.request.urlopen(req) as r: tv=json.loads(r.read().decode()).get("versions",[])[-1]
            else: tv=self.v
            url=f"https://api.purpurmc.org/v2/purpur/{tv}/latest/download"
            dest=os.path.join(self.sd,"server.jar")
            req=urllib.request.Request(url,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req) as r:
                total=int(r.headers.get('content-length',0)); dl=0
                with open(dest,'wb') as f:
                    while True:
                        c=r.read(8192)
                        if not c: break
                        f.write(c); dl+=len(c)
                        if total: self.progress.emit(int(dl/total*100))
            self.finished.emit(True,f"Purpur {tv}!")
        except Exception as e: self.finished.emit(False,str(e))
class VanillaDownloader(QThread):
    progress=pyqtSignal(int); finished=pyqtSignal(bool,str)
    def __init__(self,sd,v="latest"): super().__init__(); self.sd=sd; self.v=v
    def run(self):
        try:
            req=urllib.request.Request("https://launchermeta.mojang.com/mc/game/version_manifest_v2.json",headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req) as r: m=json.loads(r.read().decode())
            tv=m["latest"]["release"] if self.v=="latest" else self.v
            vu=next((x["url"] for x in m["versions"] if x["id"]==tv),None)
            if not vu: self.finished.emit(False,"Not found"); return
            req=urllib.request.Request(vu,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req) as r: vd=json.loads(r.read().decode())
            url=vd["downloads"]["server"]["url"]
            dest=os.path.join(self.sd,"server.jar")
            req=urllib.request.Request(url,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req) as r:
                total=int(r.headers.get('content-length',0)); dl=0
                with open(dest,'wb') as f:
                    while True:
                        c=r.read(8192)
                        if not c: break
                        f.write(c); dl+=len(c)
                        if total: self.progress.emit(int(dl/total*100))
            self.finished.emit(True,f"Vanilla {tv}!")
        except Exception as e: self.finished.emit(False,str(e))
class ModrinthDownloader(QThread):
    progress=pyqtSignal(int); finished=pyqtSignal(bool,str)
    def __init__(self,slug,mc,dest): super().__init__(); self.slug=slug; self.mc=mc; self.dest=dest
    def run(self):
        try:
            url=f"https://api.modrinth.com/v2/project/{self.slug}/version"
            req=urllib.request.Request(url,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req,timeout=30) as r: vs=json.loads(r.read().decode())
            if not vs: self.finished.emit(False,"No versions"); return
            lk={"paper","spigot","bukkit","purpur","folia"}
            t=None
            for v in vs:
                if not (set(v.get("loaders",[])) & lk): continue
                if self.mc!="latest" and self.mc not in v.get("game_versions",[]): continue
                t=v; break
            if not t: t=next((v for v in vs if set(v.get("loaders",[])) & lk),None)
            if not t: self.finished.emit(False,"No compatible"); return
            files=t.get("files",[])
            pri=next((f for f in files if f.get("primary")),files[0] if files else None)
            if not pri: self.finished.emit(False,"No file"); return
            os.makedirs(self.dest,exist_ok=True)
            dest=os.path.join(self.dest,pri["filename"])
            req=urllib.request.Request(pri["url"],headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req,timeout=120) as r:
                total=int(r.headers.get('content-length',0)); dl=0
                with open(dest,'wb') as f:
                    while True:
                        c=r.read(8192)
                        if not c: break
                        f.write(c); dl+=len(c)
                        if total: self.progress.emit(int(dl/total*100))
            if not zipfile.is_zipfile(dest): os.remove(dest); self.finished.emit(False,"Invalid"); return
            self.finished.emit(True,pri["filename"])
        except Exception as e: self.finished.emit(False,str(e))
class ModrinthSearch(QThread):
    results=pyqtSignal(list); finished=pyqtSignal()
    def __init__(self,q,ld="paper",mc=""): super().__init__(); self.q=q; self.ld=ld; self.mc=mc
    def run(self):
        try:
            fc=[[f"categories:{self.ld}"],["project_type:plugin"]]
            if self.mc and self.mc!="latest": fc.append([f"versions:{self.mc}"])
            fs=urllib.parse.quote(json.dumps(fc))
            url=f"https://api.modrinth.com/v2/search?query={urllib.parse.quote(self.q)}&facets={fs}&limit=30"
            req=urllib.request.Request(url,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req,timeout=30) as r: d=json.loads(r.read().decode())
            self.results.emit(d.get("hits",[]))
        except: self.results.emit([])
        self.finished.emit()

TEMPLATES={"Vanilla":{"software":"Vanilla","ram":"2G"},"Paper (Plugins)":{"software":"PaperMC","ram":"4G"},
    "Purpur":{"software":"Purpur","ram":"4G"},"Cracked":{"software":"PaperMC","ram":"4G"}}
VERSIONS=["latest","1.21.4","1.21.3","1.21.1","1.20.6","1.20.4","1.20.1","1.19.4","1.18.2","1.17.1","1.16.5","1.12.2","1.8.9"]

TUNNEL_LABELS = [
    ("bore", "tunnel_bore"),
    ("serveo", "tunnel_serveo"),
    ("playit", "tunnel_playit"),
    ("none", "tunnel_none"),
]
def tunnel_label(val):
    for v,k in TUNNEL_LABELS:
        if v==val: return tr(k)
    return val

class CreateServerDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("create_title")); self.setMinimumWidth(580)
        root=QVBoxLayout(self); root.setContentsMargins(16,16,16,16); root.setSpacing(12)
        title=QLabel(tr("create_title")); title.setObjectName("PageTitle"); root.addWidget(title)
        card=QFrame(); card.setObjectName("PanelCard")
        cl=QVBoxLayout(card); cl.setContentsMargins(20,18,20,18); cl.setSpacing(10)
        l=QFormLayout(); l.setSpacing(10)
        self.template=QComboBox()
        for t in TEMPLATES: self.template.addItem(t)
        self.template.currentTextChanged.connect(self.apply_template)
        self.name=QLineEdit(); self.name.setPlaceholderText(tr("ph_name"))
        self.software=QComboBox(); self.software.addItems(["PaperMC","Vanilla","Purpur"])
        self.version=QComboBox(); self.version.addItems(VERSIONS)
        self.port=QLineEdit(get_next_port()); self.port.setReadOnly(True)
        self.ram_min=QComboBox(); self.ram_min.addItems(["512M","1G","2G"])
        self.ram_max=QComboBox(); self.ram_max.addItems(["1G","2G","4G","8G","16G"]); self.ram_max.setCurrentText("2G")
        self.tunnel_provider=QComboBox()
        for val,key in TUNNEL_LABELS: self.tunnel_provider.addItem(tr(key), val)
        self.subdomain=QLineEdit(); self.subdomain.setPlaceholderText(tr("ph_subdomain"))
        self.manual_global=QLineEdit()
        self.bedrock_enabled=QCheckBox(tr("chk_bedrock")); self.bedrock_enabled.setChecked(True)
        self.bedrock_port=QLineEdit("19132")
        l.addRow(tr("lbl_template")+":",self.template); l.addRow(tr("lbl_name")+":",self.name)
        l.addRow("Software:",self.software); l.addRow(tr("lbl_version")+":",self.version)
        l.addRow(tr("lbl_port")+" (Java):",self.port); l.addRow("RAM Min:",self.ram_min); l.addRow("RAM Max:",self.ram_max)
        sep1=QLabel(tr("sep_tunnel")); sep1.setObjectName("SectionTitle"); l.addRow(sep1)
        l.addRow(tr("lbl_tunnel")+":",self.tunnel_provider)
        l.addRow("Fixed Subdomain:",self.subdomain)
        l.addRow("Manual Global:",self.manual_global)
        note=QLabel(tr("tunnel_note"))
        note.setObjectName("InfoNote"); note.setWordWrap(True); l.addRow("",note)
        sep2=QLabel(tr("sep_bedrock")); sep2.setObjectName("SectionTitle"); l.addRow(sep2)
        l.addRow(self.bedrock_enabled)
        l.addRow("Bedrock Port (UDP):",self.bedrock_port)
        cl.addLayout(l)
        b=QHBoxLayout(); b.addStretch(1)
        ok=QPushButton(tr("btn_create").lstrip("+ ")); ok.setObjectName("BtnGreen"); ok.setFixedHeight(36); ok.clicked.connect(self.accept)
        c=QPushButton(tr("btn_cancel")); c.setObjectName("BtnBlue"); c.setFixedHeight(36); c.clicked.connect(self.reject)
        b.addWidget(ok); b.addWidget(c); cl.addLayout(b)
        root.addWidget(card)
    def apply_template(self,t):
        td=TEMPLATES.get(t)
        if not td: return
        sw=td.get("software")
        i=self.software.findText(sw)
        if i>=0: self.software.setCurrentIndex(i)
        rm=td.get("ram")
        i=self.ram_max.findText(rm)
        if i>=0: self.ram_max.setCurrentIndex(i)
    def get_data(self):
        n=self.name.text().strip()
        sf="".join(c if c.isalnum() else "_" for c in n)
        sd=os.path.join(SERVERS_DIR,sf); os.makedirs(sd,exist_ok=True)
        sub = re.sub(r'[^a-z0-9-]', '', self.subdomain.text().strip().lower())
        if not sub: sub = f"agc-{random_name(6)}"
        return {"name":n,"hostname":f"{sf.lower()}.local","port":self.port.text(),
                "ram_min":self.ram_min.currentText(),"ram_max":self.ram_max.currentText(),
                "software":self.software.currentText(),"version":self.version.currentText(),
                "dir":sd,"java_path":"","cpu_cores":"auto",
                "tunnel_provider":self.tunnel_provider.currentData(),
                "subdomain":sub,"manual_global":self.manual_global.text().strip(),
                "bedrock_enabled":self.bedrock_enabled.isChecked(),"bedrock_port":self.bedrock_port.text(),
                "created":datetime.datetime.now().strftime("%Y-%m-%d")}

class ImportServerDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("import_title")); self.setMinimumWidth(520)
        root=QVBoxLayout(self); root.setContentsMargins(16,16,16,16); root.setSpacing(12)
        title=QLabel(tr("import_title")); title.setObjectName("PageTitle"); root.addWidget(title)
        card=QFrame(); card.setObjectName("PanelCard")
        cl=QVBoxLayout(card); cl.setContentsMargins(20,18,20,18); cl.setSpacing(10)
        l=QFormLayout(); l.setSpacing(10)
        self.path=QLineEdit(); br=QPushButton(tr("btn_browse")); br.setObjectName("BtnBlue"); br.clicked.connect(self.browse)
        self.name=QLineEdit(); self.port=QLineEdit(get_next_port())
        self.tunnel_provider=QComboBox()
        for val,key in TUNNEL_LABELS: self.tunnel_provider.addItem(tr(key), val)
        self.subdomain=QLineEdit()
        self.manual_global=QLineEdit()
        self.bedrock_port=QLineEdit("19132")
        l.addRow(tr("lbl_path")+":",self.path); l.addRow("",br)
        l.addRow(tr("lbl_name")+":",self.name); l.addRow(tr("lbl_port")+":",self.port)
        l.addRow(tr("lbl_tunnel")+":",self.tunnel_provider)
        l.addRow("Subdomain:",self.subdomain)
        l.addRow("Manual Global:",self.manual_global)
        l.addRow("Bedrock Port:",self.bedrock_port)
        cl.addLayout(l)
        b=QHBoxLayout(); b.addStretch(1)
        ok=QPushButton(tr("btn_import")); ok.setObjectName("BtnGreen"); ok.setFixedHeight(36); ok.clicked.connect(self.accept)
        c=QPushButton(tr("btn_cancel")); c.setObjectName("BtnBlue"); c.setFixedHeight(36); c.clicked.connect(self.reject)
        b.addWidget(ok); b.addWidget(c); cl.addLayout(b)
        root.addWidget(card)
    def browse(self):
        p=QFileDialog.getExistingDirectory(self,tr("lbl_path"))
        if p:
            self.path.setText(p)
            if not self.name.text(): self.name.setText(os.path.basename(p))
    def get_data(self):
        src=self.path.text().strip()
        n=self.name.text().strip() or os.path.basename(src)
        sf="".join(c if c.isalnum() else "_" for c in n)
        dest=os.path.join(SERVERS_DIR,sf)
        if os.path.abspath(src)!=os.path.abspath(dest):
            try:
                if os.path.exists(dest): shutil.rmtree(dest)
                shutil.copytree(src,dest)
            except: return None
        sub=re.sub(r'[^a-z0-9-]','',self.subdomain.text().strip().lower())
        if not sub: sub=f"agc-{random_name(6)}"
        return {"name":n,"hostname":f"{sf.lower()}.local","port":self.port.text(),
                "ram_min":"1G","ram_max":"2G","software":"Imported","version":"Existing",
                "dir":dest,"java_path":"","cpu_cores":"auto",
                "tunnel_provider":self.tunnel_provider.currentData(),
                "subdomain":sub,"manual_global":self.manual_global.text().strip(),
                "bedrock_enabled":True,"bedrock_port":self.bedrock_port.text(),
                "created":datetime.datetime.now().strftime("%Y-%m-%d"),"imported":True}

class ServerCard(QFrame):
    clicked=pyqtSignal(dict); delete_requested=pyqtSignal(str)
    def __init__(self,data):
        super().__init__()
        self.data=data; self.setObjectName("ServerCard")
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor)); self.setFixedHeight(100)
        l=QHBoxLayout(self); info=QVBoxLayout()
        n=QLabel(data.get("name","?")); n.setObjectName("ServerCardTitle")
        h=QLabel(f"{data.get('hostname','')}:{data.get('port','')}"); h.setObjectName("ServerCardSub")
        tp = data.get("tunnel_provider","bore")
        labels = {"bore":"🌐 Dyn","serveo":"📌 Fixed","playit":"🎯 playit","none":"🔒 LAN"}
        ga = labels.get(tp, tp)
        sub = data.get("subdomain","")
        if tp == "serveo" and sub: ga = f"📌 {sub}.serveo.net"
        br = " + PE" if data.get("bedrock_enabled",False) else ""
        s=QLabel(f"{data.get('software','')} {data.get('version','')} | {data.get('ram_max','2G')} | {ga}{br}"); s.setObjectName("ServerCardSub")
        info.addWidget(n); info.addWidget(h); info.addWidget(s)
        dl=QPushButton("X"); dl.setObjectName("DeleteBtn"); dl.setFixedSize(30,30)
        dl.clicked.connect(lambda: self.delete_requested.emit(self.data["name"]))
        l.addLayout(info); l.addStretch(); l.addWidget(dl); l.setContentsMargins(20,15,20,15)
    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton: self.clicked.emit(self.data)
        super().mousePressEvent(e)

class ServerListPage(QWidget):
    server_selected=pyqtSignal(dict)
    def __init__(self):
        super().__init__()
        l=QVBoxLayout(self); l.setContentsMargins(50,30,50,30); l.setSpacing(20)
        title=QLabel(tr("page_servers")); title.setObjectName("PageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        act=QHBoxLayout(); act.addStretch()
        imp=QPushButton(tr("btn_import")); imp.setObjectName("BtnOrange"); imp.clicked.connect(self.import_server)
        crt=QPushButton(tr("btn_create")); crt.setObjectName("BtnGreen"); crt.clicked.connect(self.create_server)
        act.addWidget(imp); act.addWidget(crt)
        self.stack=QStackedWidget()
        empty=QWidget(); el=QVBoxLayout(empty)
        et=QLabel(tr("no_servers")); et.setObjectName("PanelTitle")
        et.setAlignment(Qt.AlignmentFlag.AlignCenter)
        es=QLabel("🖥"); es.setStyleSheet("font-size:48px;")
        es.setAlignment(Qt.AlignmentFlag.AlignCenter)
        el.addStretch(); el.addWidget(es); el.addWidget(et); el.addStretch()
        self.gw=QWidget(); self.grid=QGridLayout(self.gw); self.grid.setSpacing(20)
        self.grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.stack.addWidget(empty); self.stack.addWidget(self.gw)
        l.addWidget(title); l.addLayout(act); l.addWidget(self.stack)
        self.refresh()
    def refresh(self):
        for i in reversed(range(self.grid.count())):
            w=self.grid.itemAt(i).widget()
            if w: w.setParent(None)
        sv=load_servers()
        if not sv: self.stack.setCurrentIndex(0)
        else:
            self.stack.setCurrentIndex(1); r=c=0
            for s in sv:
                cd=ServerCard(s)
                cd.clicked.connect(self.server_selected.emit)
                cd.delete_requested.connect(self.delete_server)
                self.grid.addWidget(cd,r,c); c+=1
                if c>1: c=0; r+=1
    def create_server(self):
        d=CreateServerDialog()
        if d.exec():
            data=d.get_data()
            if not data["name"]: return
            sv=load_servers()
            if any(s["name"]==data["name"] for s in sv):
                QMessageBox.warning(self,tr("err_error"),tr("msg_exists")); return
            sv.append(data); save_servers(sv); log_activity(tr("btn_create").lstrip("+ "),data["name"])
            self.refresh(); self.server_selected.emit(data)
    def import_server(self):
        d=ImportServerDialog()
        if d.exec():
            data=d.get_data()
            if not data: QMessageBox.warning(self,tr("err_error"),tr("msg_failed")); return
            sv=load_servers()
            if any(s["name"]==data["name"] for s in sv):
                QMessageBox.warning(self,tr("err_error"),tr("msg_exists")); return
            sv.append(data); save_servers(sv); self.refresh(); self.server_selected.emit(data)
    def delete_server(self,name):
        if QMessageBox.question(self,tr("btn_delete"),tr("confirm_delete").format(name=name))==QMessageBox.StandardButton.Yes:
            save_servers([s for s in load_servers() if s["name"]!=name]); self.refresh()

class ConsoleWidget(QWidget):
    def __init__(self,process):
        super().__init__(); self.process=process; self.history=[]; self.hist_idx=-1
        l=QVBoxLayout(self); l.setContentsMargins(10,10,10,10)
        top=QHBoxLayout()
        self.search=QLineEdit(); self.search.setPlaceholderText(tr("ph_search"))
        self.search.textChanged.connect(self.apply_filter)
        self.filter=QComboBox(); self.filter.addItems(["ALL","INFO","WARN","ERROR","TUNNEL","DICTATOR"])
        self.filter.currentTextChanged.connect(self.apply_filter)
        clr=QPushButton(tr("btn_clear")); clr.setObjectName("BtnOrange"); clr.clicked.connect(self.clear)
        top.addWidget(self.search); top.addWidget(self.filter); top.addWidget(clr)
        self.out=QPlainTextEdit(); self.out.setObjectName("ConsoleOutput"); self.out.setReadOnly(True)
        self.out.setMaximumBlockCount(5000)
        self.inp=QLineEdit(); self.inp.setObjectName("ConsoleInput"); self.inp.setPlaceholderText(tr("ph_command"))
        self.inp.returnPressed.connect(self.send); self.inp.installEventFilter(self)
        il=QHBoxLayout(); send=QPushButton(tr("btn_send")); send.setObjectName("BtnBlue"); send.clicked.connect(self.send)
        il.addWidget(self.inp); il.addWidget(send)
        l.addLayout(top); l.addWidget(self.out); l.addLayout(il)
        self._lines=[]
    def eventFilter(self,obj,ev):
        if obj==self.inp and ev.type()==ev.Type.KeyPress:
            if ev.key()==Qt.Key.Key_Up and self.history and self.hist_idx<len(self.history)-1:
                self.hist_idx+=1; self.inp.setText(self.history[-(self.hist_idx+1)]); return True
            elif ev.key()==Qt.Key.Key_Down:
                if self.hist_idx>0: self.hist_idx-=1; self.inp.setText(self.history[-(self.hist_idx+1)]); return True
                elif self.hist_idx==0: self.hist_idx=-1; self.inp.clear(); return True
        return super().eventFilter(obj,ev)
    def append(self,text):
        ts=datetime.datetime.now().strftime("%H:%M:%S")
        for line in text.split("\n"):
            if not line.strip(): continue
            if "Cannot invoke \"net.minecraft.server.level.ServerLevel.getGameRules" in line: continue
            if "net.minecraft.commands.Commands.executeCommandInContext" in line: continue
            if "unexpected error occurred while trying to execute that command" in line: continue
            if "\tat " in line and "paper-26.2.jar" in line: continue
            tag="CHAT"
            if "[Dictator]" in line: tag="DICTATOR"
            elif "[Tunnel]" in line: tag="TUNNEL"
            elif "[Geyser]" in line: tag="INFO"
            elif "ERROR" in line or "SEVERE" in line: tag="ERROR"
            elif "WARN" in line: tag="WARN"
            elif "INFO" in line: tag="INFO"
            self._lines.append(f"[{ts}][{tag}] {line}")
        if len(self._lines)>5000: self._lines=self._lines[-5000:]
        self.refresh_display()
    def refresh_display(self):
        q=self.search.text().lower(); f=self.filter.currentText()
        sn=self._lines
        if f!="ALL": sn=[ln for ln in sn if f"[{f}]" in ln]
        if q: sn=[ln for ln in sn if q in ln.lower()]
        self.out.setPlainText("\n".join(sn))
        sb=self.out.verticalScrollBar(); sb.setValue(sb.maximum())
    def apply_filter(self): self.refresh_display()
    def clear(self): self._lines.clear(); self.out.clear()
    def send(self):
        cmd=self.inp.text().strip()
        if not cmd: return
        self.history.append(cmd); self.hist_idx=-1
        if self.process.state()==QProcess.ProcessState.Running:
            self.process.write(f"{cmd}\n".encode()); self.append(f"> {cmd}")
        else: self.append("> ERROR: not running")
        self.inp.clear()

class PlayersTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        outer=QVBoxLayout(self)
        act=QHBoxLayout()
        self.inp=QLineEdit(); self.inp.setPlaceholderText(tr("ph_player"))
        for nm,cmd,st in [(tr("btn_ops"),"op","BtnPurple"),("DE-OP","deop","BtnOrange"),(tr("btn_kick"),"kick","BtnOrange"),
                            (tr("btn_banned"),"ban","BtnRed"),(tr("btn_unban"),"pardon","BtnGreen"),
                            ("WL+","whitelist add","BtnBlue"),("WL-","whitelist remove","BtnBlue")]:
            b=QPushButton(nm); b.setObjectName(st)
            b.clicked.connect(lambda _,c=cmd: self.cmd(c)); act.addWidget(b)
        ref=QPushButton(tr("btn_refresh")); ref.setObjectName("BtnGreen"); ref.clicked.connect(self.refresh_all)
        act.addWidget(ref); act.insertWidget(0,self.inp)
        outer.addLayout(act)
        self.tabs=QTabWidget()
        self.online_w,self.online=self._lst("Online")
        self.all_k_w,self.all_k=self._lst("Known")
        self.ops_w,self.ops=self._lst(tr("btn_ops"))
        self.wl_w,self.wl=self._lst(tr("btn_whitelist"))
        self.banned_w,self.banned=self._lst(tr("btn_banned"))
        self.bips_w,self.bips=self._lst(tr("btn_banned_ips"))
        for t,w in [(tr("st_online"),self.online_w),(tr("tab_all_known"),self.all_k_w),(tr("btn_ops"),self.ops_w),
                     (tr("btn_whitelist"),self.wl_w),(tr("btn_banned"),self.banned_w),(tr("btn_banned_ips"),self.bips_w)]:
            self.tabs.addTab(w,t)
        outer.addWidget(self.tabs)
    def _lst(self,name):
        w=QWidget(); l=QVBoxLayout(w)
        lst=QListWidget(); l.addWidget(lst); w._ref=lst
        return w,lst
    def cmd(self,base):
        n=self.inp.text().strip()
        if not n:
            QMessageBox.warning(self,tr("err_error"),tr("err_player_name")); return
        self.detail.send_command(f"{base} {n}")
        QTimer.singleShot(1500,self.refresh_all)
    def refresh_all(self):
        if not self.detail.current_server: return
        sd=self.detail.current_server["dir"]
        self.all_k.clear(); found=set()
        for p in read_sj(sd,"usercache.json"):
            n = p.get('name','?')
            if n and n not in found and n!='?':
                self.all_k.addItem(n); found.add(n)
        for fn in ["ops.json","whitelist.json","banned-players.json"]:
            for p in read_sj(sd,fn):
                n = p.get('name','?')
                if n and n not in found and n!='?':
                    self.all_k.addItem(n); found.add(n)
        self.ops.clear()
        for p in read_sj(sd,"ops.json"):
            n=p.get('name','?'); lvl=p.get('level',4)
            self.ops.addItem(f"{n} (lvl {lvl})")
        self.wl.clear()
        for p in read_sj(sd,"whitelist.json"): self.wl.addItem(p.get("name","?"))
        self.banned.clear()
        for p in read_sj(sd,"banned-players.json"):
            n=p.get('name','?'); r=p.get('reason',tr("no_reason"))
            self.banned.addItem(f"{n} - {r}")
        self.bips.clear()
        for p in read_sj(sd,"banned-ips.json"):
            ip=p.get('ip','?'); r=p.get('reason',tr("no_reason"))
            self.bips.addItem(f"{ip} - {r}")
        if self.detail.process.state()==QProcess.ProcessState.Running:
            self.detail.send_command("list")
    def parse_online(self,text):
        m=re.search(r"There are (\d+) of a max of \d+ players online:?\s*(.*)",text)
        if m:
            self.online.clear()
            for p in [x.strip() for x in m.group(2).split(",") if x.strip()]: self.online.addItem(p)
            self.detail.update_player_count(len([x for x in m.group(2).split(",") if x.strip()]))

class WorldsTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        l=QVBoxLayout(self); l.setContentsMargins(20,20,20,20); l.setSpacing(12)
        title=QLabel(tr("worlds_title")); title.setObjectName("SectionTitle"); l.addWidget(title)
        info=QLabel(tr("worlds_note"))
        info.setObjectName("InfoNote"); info.setWordWrap(True); l.addWidget(info)
        self.tbl=QTableWidget(0,4); self.tbl.setHorizontalHeaderLabels([tr("col_world"),tr("col_type"),tr("col_size"),tr("col_path")])
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        l.addWidget(self.tbl)
        r=QHBoxLayout()
        for nm,fn,st in [(tr("btn_open"),"open","BtnBlue"),(tr("btn_backup_now"),"bak","BtnOrange"),
                          (tr("btn_delete"),"delete","BtnRed"),(tr("btn_refresh"),"refresh","BtnGreen")]:
            b=QPushButton(nm); b.setObjectName(st); b.clicked.connect(getattr(self,fn)); r.addWidget(b)
        r.addStretch(); l.addLayout(r); l.addStretch()
    def refresh(self):
        self.tbl.setRowCount(0)
        if not self.detail.current_server: return
        for w in detect_worlds(self.detail.current_server["dir"]):
            r=self.tbl.rowCount(); self.tbl.insertRow(r)
            self.tbl.setItem(r,0,QTableWidgetItem(w["name"]))
            self.tbl.setItem(r,1,QTableWidgetItem(w["type"]))
            self.tbl.setItem(r,2,QTableWidgetItem(human_size(get_dir_size(w["path"]))))
            self.tbl.setItem(r,3,QTableWidgetItem(w["path"]))
    def _sel(self):
        r=self.tbl.currentRow()
        if r<0: return None,None
        return self.tbl.item(r,0).text(), self.tbl.item(r,3).text()
    def open(self):
        _,p=self._sel()
        if p:
            if os.name=='nt': os.startfile(p)
            else: subprocess.Popen(["xdg-open",p])
    def bak(self):
        n,p=self._sel()
        if not p: return
        os.makedirs(BACKUPS_DIR,exist_ok=True)
        ts=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        out=os.path.join(BACKUPS_DIR,f"{self.detail.current_server['name']}_{n.replace('/','_')}_{ts}")
        try:
            shutil.make_archive(out,'zip',os.path.dirname(p),os.path.basename(p))
            QMessageBox.information(self,tr("btn_backup_now"),tr("msg_saved"))
        except Exception as e: QMessageBox.critical(self,tr("err_error"),str(e))
    def delete(self):
        n,p=self._sel()
        if not p: return
        if QMessageBox.question(self,tr("btn_delete"),tr("confirm_delete").format(name=n))==QMessageBox.StandardButton.Yes:
            self.bak(); shutil.rmtree(p,ignore_errors=True); self.refresh()

class BackupTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        l=QVBoxLayout(self); l.setContentsMargins(20,20,20,20)
        self.lst=QListWidget(); l.addWidget(self.lst)
        row=QHBoxLayout()
        for nm,fn,st in [(tr("btn_backup_now"),"create","BtnGreen"),(tr("btn_restore"),"restore","BtnOrange"),
                          (tr("btn_delete"),"delete","BtnRed"),(tr("btn_upload"),"upload","BtnPurple"),
                          (tr("btn_refresh"),"refresh","BtnBlue"),(tr("btn_folder"),"open_folder","")]:
            b=QPushButton(nm); b.setObjectName(st); b.clicked.connect(getattr(self,fn)); row.addWidget(b)
        l.addLayout(row); l.addStretch()
    def refresh(self):
        self.lst.clear()
        if not self.detail.current_server: return
        n=self.detail.current_server["name"]
        if not os.path.exists(BACKUPS_DIR): return
        for f in sorted(os.listdir(BACKUPS_DIR),reverse=True):
            if f.startswith(n+"_") and f.endswith(".zip"):
                self.lst.addItem(f"{f}  [{human_size(os.path.getsize(os.path.join(BACKUPS_DIR,f)))}]")
    def create(self):
        if not self.detail.current_server: return
        sd=self.detail.current_server["dir"]; n=self.detail.current_server["name"]
        os.makedirs(BACKUPS_DIR,exist_ok=True)
        ts=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        out=os.path.join(BACKUPS_DIR,f"{n}_full_{ts}")
        try:
            self.detail.send_command("save-all"); time.sleep(1)
            shutil.make_archive(out,'zip',sd)
            QMessageBox.information(self,"OK",tr("msg_saved")); self.refresh()
        except Exception as e: QMessageBox.critical(self,tr("err_error"),str(e))
    def restore(self):
        i=self.lst.currentItem()
        if not i: return
        fn=i.text().split("  ")[0]; sd=self.detail.current_server["dir"]
        if self.detail.process.state()==QProcess.ProcessState.Running:
            QMessageBox.warning(self,tr("err_error"),tr("msg_stop_first")); return
        if QMessageBox.question(self,tr("btn_restore"),tr("confirm_restore").format(name=fn))==QMessageBox.StandardButton.Yes:
            try:
                with zipfile.ZipFile(os.path.join(BACKUPS_DIR,fn)) as z: z.extractall(sd)
                QMessageBox.information(self,"OK",tr("msg_restored"))
            except Exception as e: QMessageBox.critical(self,tr("err_error"),str(e))
    def delete(self):
        i=self.lst.currentItem()
        if not i: return
        fn=i.text().split("  ")[0]
        try: os.remove(os.path.join(BACKUPS_DIR,fn)); self.refresh()
        except: pass
    def upload(self):
        i=self.lst.currentItem()
        if not i: return
        if not rclone_available(): QMessageBox.warning(self,"rclone",tr("msg_install_rclone")); return
        cfg=load_config()
        fn=i.text().split("  ")[0]
        dlg=QDialog(self); dlg.setWindowTitle(tr("msg_uploading")); dlg.setFixedSize(300,80)
        l=QVBoxLayout(dlg); l.addWidget(QLabel(tr("msg_uploading"))); dlg.show()
        dl=RcloneUpload(os.path.join(BACKUPS_DIR,fn),cfg["cloud_remote"],f"{cfg['cloud_folder']}/{self.detail.current_server['name']}/{fn}")
        def done(ok,msg): dlg.close(); QMessageBox.information(self,tr("nav_cloud"),msg)
        dl.finished.connect(done); self._dl=dl; dl.start()
    def open_folder(self):
        os.makedirs(BACKUPS_DIR,exist_ok=True)
        if os.name=='nt': os.startfile(BACKUPS_DIR)
        else: subprocess.Popen(["xdg-open",BACKUPS_DIR])

# ============ PLUGINS TAB WITH CATALOG ============
class PluginsTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        outer=QVBoxLayout(self)
        self.tabs=QTabWidget()
        # --- Catalog Tab ---
        cw=QWidget(); cl=QVBoxLayout(cw)
        top=QHBoxLayout()
        self.cat_search=QLineEdit(); self.cat_search.setPlaceholderText(tr("ph_cat_search"))
        self.cat_search.textChanged.connect(self.refresh_catalog)
        self.cat_filter=QComboBox()
        cats = sorted(set(p[2] for p in POPULAR_PLUGINS))
        self.cat_filter.addItem(tr("all_categories"))
        for c in cats: self.cat_filter.addItem(c)
        self.cat_filter.currentTextChanged.connect(self.refresh_catalog)
        self.cat_ver=QComboBox(); self.cat_ver.addItem(tr("auto"))
        for v in VERSIONS[1:]: self.cat_ver.addItem(v)
        top.addWidget(self.cat_search); top.addWidget(QLabel(tr("lbl_category"))); top.addWidget(self.cat_filter)
        top.addWidget(QLabel(tr("lbl_mc"))); top.addWidget(self.cat_ver)
        cl.addLayout(top)
        self.cat_table=QTableWidget(0,5)
        self.cat_table.setHorizontalHeaderLabels([tr("col_name"),tr("lbl_category"),tr("col_description"),tr("col_status"),"Slug"])
        self.cat_table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch)
        self.cat_table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.ResizeToContents)
        self.cat_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.cat_table.setColumnHidden(4,True)
        cl.addWidget(self.cat_table)
        crow=QHBoxLayout()
        inst=QPushButton(tr("btn_install_sel")); inst.setObjectName("BtnGreen"); inst.clicked.connect(self.catalog_install_sel)
        inst_all=QPushButton(tr("btn_install_all")); inst_all.setObjectName("BtnOrange"); inst_all.clicked.connect(self.catalog_install_all)
        ref=QPushButton(tr("btn_refresh")); ref.setObjectName("BtnBlue"); ref.clicked.connect(self.refresh_catalog)
        crow.addWidget(inst); crow.addWidget(inst_all); crow.addWidget(ref); crow.addStretch()
        cl.addLayout(crow)
        self.tabs.addTab(cw,tr("tab_catalog"))
        # --- Search Tab ---
        sw=QWidget(); sl=QVBoxLayout(sw)
        sr=QHBoxLayout()
        self.q=QLineEdit(); self.q.setPlaceholderText(tr("ph_modrinth"))
        self.q.returnPressed.connect(self.search)
        self.ver=QComboBox(); self.ver.addItem(tr("auto"))
        for v in VERSIONS[1:]: self.ver.addItem(v)
        sb=QPushButton(tr("btn_search")); sb.setObjectName("BtnBlue"); sb.clicked.connect(self.search)
        sr.addWidget(self.q); sr.addWidget(QLabel(tr("lbl_mc"))); sr.addWidget(self.ver); sr.addWidget(sb)
        sl.addLayout(sr)
        self.results=QTableWidget(0,4)
        self.results.setHorizontalHeaderLabels([tr("col_name"),tr("col_author"),tr("col_downloads"),tr("col_description")])
        self.results.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch)
        self.results.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        sl.addWidget(self.results)
        rb=QHBoxLayout(); sinst=QPushButton(tr("btn_install_sel")); sinst.setObjectName("BtnGreen")
        sinst.clicked.connect(self.install_sel); rb.addWidget(sinst); rb.addStretch(); sl.addLayout(rb)
        self.tabs.addTab(sw,tr("tab_search"))
        # --- Installed Tab ---
        iw=QWidget(); il=QVBoxLayout(iw)
        self.inst=QListWidget(); il.addWidget(self.inst)
        ib=QHBoxLayout()
        for nm,fn,st in [(tr("btn_open_folder"),"open_folder","BtnBlue"),(tr("btn_refresh"),"refresh_inst","BtnGreen"),
                          (tr("btn_clean"),"clean","BtnOrange"),(tr("btn_delete"),"delete_inst","BtnRed"),
                          (tr("btn_toggle"),"toggle","BtnPurple"),(tr("btn_update_all"),"update_all","BtnGreen")]:
            b=QPushButton(nm); b.setObjectName(st); b.clicked.connect(getattr(self,fn)); ib.addWidget(b)
        il.addLayout(ib); self.tabs.addTab(iw,tr("tab_installed"))
        # --- URL Tab ---
        uw=QWidget(); ul=QVBoxLayout(uw)
        ul.addWidget(QLabel(tr("lbl_url")))
        self.url=QLineEdit(); ul.addWidget(self.url)
        b1=QPushButton(tr("btn_download")); b1.setObjectName("BtnBlue"); b1.clicked.connect(self.dl_url); ul.addWidget(b1)
        ul.addStretch(); self.tabs.addTab(uw,tr("tab_url"))
        outer.addWidget(self.tabs)
        self.refresh_inst()
        self.refresh_catalog()
    def refresh_catalog(self):
        q=self.cat_search.text().lower().strip()
        cat=self.cat_filter.currentText()
        self.cat_table.setRowCount(0)
        # installed files
        installed=[]
        if self.detail.current_server:
            pdir=os.path.join(self.detail.current_server["dir"],"plugins")
            if os.path.exists(pdir):
                installed=[f.lower() for f in os.listdir(pdir) if f.endswith(".jar") or f.endswith(".jar.disabled")]
        count=0
        for name,slug,c,desc in POPULAR_PLUGINS:
            if cat!=tr("all_categories") and c!=cat: continue
            if q and q not in name.lower() and q not in slug.lower() and q not in desc.lower(): continue
            r=self.cat_table.rowCount(); self.cat_table.insertRow(r)
            self.cat_table.setItem(r,0,QTableWidgetItem(name))
            self.cat_table.setItem(r,1,QTableWidgetItem(c))
            self.cat_table.setItem(r,2,QTableWidgetItem(desc))
            # Check if already installed (by slug match)
            is_inst = any(slug.lower() in f for f in installed)
            self.cat_table.setItem(r,3,QTableWidgetItem(tr("st_installed") if is_inst else ""))
            self.cat_table.setItem(r,4,QTableWidgetItem(slug))
            count+=1
        self.tabs.setTabText(0, f"{tr('tab_catalog')} ({count})")
    def catalog_install_sel(self):
        rows=set(i.row() for i in self.cat_table.selectedIndexes())
        if not rows: QMessageBox.warning(self,tr("err_error"),tr("err_select_plugins")); return
        if not self.detail.current_server: QMessageBox.warning(self,tr("err_error"),tr("err_select_server")); return
        v=self.cat_ver.currentText() if self.cat_ver.currentText()!="Auto" else self.detail.current_server.get("version","latest")
        self._queue = []
        for row in rows:
            name=self.cat_table.item(row,0).text()
            slug=self.cat_table.item(row,4).text()
            self._queue.append((name,slug))
        self._ver = v
        self._process_next_catalog()
    def catalog_install_all(self):
        r = QMessageBox.question(self,tr("install_all_title"),
            tr("install_all_msg").format(n=self.cat_table.rowCount()),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if r != QMessageBox.StandardButton.Yes: return
        if not self.detail.current_server: QMessageBox.warning(self,tr("err_error"),tr("err_select_server")); return
        v=self.cat_ver.currentText() if self.cat_ver.currentText()!="Auto" else self.detail.current_server.get("version","latest")
        self._queue = []
        for row in range(self.cat_table.rowCount()):
            name=self.cat_table.item(row,0).text()
            slug=self.cat_table.item(row,4).text()
            self._queue.append((name,slug))
        self._ver = v
        self._process_next_catalog()
    def _process_next_catalog(self):
        if not self._queue:
            QMessageBox.information(self,"OK",tr("msg_all_installed"))
            self.refresh_catalog(); self.refresh_inst()
            return
        name, slug = self._queue.pop(0)
        pd=os.path.join(self.detail.current_server["dir"],"plugins"); os.makedirs(pd,exist_ok=True)
        dlg=QDialog(self); dlg.setWindowTitle(tr("msg_installing_name").format(name=name)); dlg.setFixedSize(320,80)
        l=QVBoxLayout(dlg); pb=QProgressBar(); l.addWidget(pb); dlg.show()
        dl=ModrinthDownloader(slug,self._ver,pd); dl.progress.connect(pb.setValue)
        def done(ok,msg):
            dlg.close()
            if slug in ("geyser","floodgate") and ok:
                QTimer.singleShot(1500, lambda: self._edit_geyser())
            QTimer.singleShot(200, self._process_next_catalog)
        dl.finished.connect(done); self._dl=dl; dl.start()
    def _edit_geyser(self):
        if not self.detail.current_server: return
        sd = self.detail.current_server["dir"]
        bp = self.detail.current_server.get("bedrock_port","19132")
        n = edit_geyser_config(sd, bp)
        if n: QMessageBox.information(self,"Geyser",tr("msg_geyser"))
    def search(self):
        q=self.q.text().strip()
        if not q: return
        self.results.setRowCount(0)
        v=self.ver.currentText() if self.ver.currentText()!="Auto" else "latest"
        self._s=ModrinthSearch(q,"paper",v); self._s.results.connect(self.on_results); self._s.start()
    def on_results(self,hits):
        for h in hits:
            r=self.results.rowCount(); self.results.insertRow(r)
            self.results.setItem(r,0,QTableWidgetItem(h.get("title","")))
            self.results.setItem(r,1,QTableWidgetItem(h.get("author","")))
            self.results.setItem(r,2,QTableWidgetItem(str(h.get("downloads",0))))
            self.results.setItem(r,3,QTableWidgetItem(h.get("description","")[:80]))
            self.results.item(r,0).setData(Qt.ItemDataRole.UserRole,h.get("slug",""))
    def install_sel(self):
        r=self.results.currentRow()
        if r<0: return
        slug=self.results.item(r,0).data(Qt.ItemDataRole.UserRole)
        if not slug or not self.detail.current_server: return
        pd=os.path.join(self.detail.current_server["dir"],"plugins"); os.makedirs(pd,exist_ok=True)
        v=self.ver.currentText() if self.ver.currentText()!="Auto" else self.detail.current_server.get("version","latest")
        dlg=QDialog(self); dlg.setWindowTitle(tr("msg_installing")); dlg.setFixedSize(300,80)
        l=QVBoxLayout(dlg); pb=QProgressBar(); l.addWidget(pb); dlg.show()
        dl=ModrinthDownloader(slug,v,pd); dl.progress.connect(pb.setValue)
        def done(ok,msg):
            dlg.close(); QMessageBox.information(self,tr("msg_result"),msg); self.refresh_inst(); self.refresh_catalog()
            if slug in ("geyser","floodgate") and ok:
                QTimer.singleShot(1500, lambda: self._edit_geyser())
        dl.finished.connect(done); self._dl=dl; dl.start()
    def refresh_inst(self):
        self.inst.clear()
        if not self.detail.current_server: return
        pd=os.path.join(self.detail.current_server["dir"],"plugins")
        if not os.path.exists(pd): return
        for f in sorted(os.listdir(pd)):
            if f.endswith(".jar") or f.endswith(".jar.disabled"):
                s=human_size(os.path.getsize(os.path.join(pd,f)))
                st=tr("st_disabled") if f.endswith(".disabled") else tr("st_enabled")
                self.inst.addItem(f"{f}  [{s}] {st}")
    def open_folder(self):
        pd=os.path.join(self.detail.current_server["dir"],"plugins"); os.makedirs(pd,exist_ok=True)
        if os.name=='nt': os.startfile(pd)
        else: subprocess.Popen(["xdg-open",pd])
    def clean(self):
        n=auto_clean_plugins(self.detail.current_server["dir"])
        QMessageBox.information(self,tr("btn_clean"),tr("msg_clean").format(n=n)); self.refresh_inst()
    def delete_inst(self):
        i=self.inst.currentItem()
        if not i: return
        fn=i.text().split("  ")[0]
        try: os.remove(os.path.join(self.detail.current_server["dir"],"plugins",fn)); self.refresh_inst()
        except: pass
    def toggle(self):
        i=self.inst.currentItem()
        if not i: return
        fn=i.text().split("  ")[0]
        pd=os.path.join(self.detail.current_server["dir"],"plugins"); fp=os.path.join(pd,fn)
        try:
            if fn.endswith(".disabled"): os.rename(fp,os.path.join(pd,fn[:-9]))
            else: os.rename(fp,fp+".disabled")
            self.refresh_inst()
        except: pass
    def update_all(self):
        QMessageBox.information(self,tr("btn_update_all"),tr("msg_update_hint"))
    def dl_url(self):
        url=self.url.text().strip()
        if not url or not self.detail.current_server: return
        pd=os.path.join(self.detail.current_server["dir"],"plugins"); os.makedirs(pd,exist_ok=True)
        fn=url.split("/")[-1].split("?")[0] or "plugin.jar"
        try:
            req=urllib.request.Request(url,headers={"User-Agent":USER_AGENT})
            with urllib.request.urlopen(req,timeout=120) as r: data=r.read()
            if len(data)<10240: QMessageBox.warning(self,tr("err_invalid"),"Small"); return
            open(os.path.join(pd,fn),"wb").write(data)
            QMessageBox.information(self,"OK",tr("msg_downloaded").format(fn=fn)); self.refresh_inst()
        except Exception as e: QMessageBox.critical(self,tr("err_error"),str(e))

class PerformanceTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        l=QVBoxLayout(self); l.setContentsMargins(20,20,20,20)
        g=QGridLayout()
        self.tps=self._c("TPS","20.0"); self.mspt=self._c("MSPT","0.0")
        self.ram=self._c("RAM","N/A"); self.disk=self._c("Disk","N/A")
        self.up=self._c("Uptime","0m"); self.pl=self._c("Players","0")
        g.addWidget(self.tps,0,0); g.addWidget(self.mspt,0,1); g.addWidget(self.ram,0,2)
        g.addWidget(self.disk,1,0); g.addWidget(self.up,1,1); g.addWidget(self.pl,1,2)
        l.addLayout(g); l.addStretch()
    def _c(self,lbl,v):
        c=QFrame(); c.setObjectName("StatCard"); l=QVBoxLayout(c)
        vl=QLabel(v); vl.setObjectName("StatValue"); vl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ll=QLabel(lbl); ll.setObjectName("StatLabel"); ll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        l.addWidget(vl); l.addWidget(ll); c.value_label=vl; return c
    def update_tps(self,tps): self.tps.value_label.setText(f"{tps:.1f}")
    def refresh_disk(self):
        if self.detail.current_server: self.disk.value_label.setText(human_size(get_dir_size(self.detail.current_server["dir"])))
    def update_uptime(self,s):
        h=s//3600; m=(s%3600)//60
        self.up.value_label.setText(f"{h}h {m}m")

class OptionsTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail; self.server=None
        outer=QVBoxLayout(self)
        scroll=QScrollArea(); scroll.setWidgetResizable(True)
        c=QWidget(); l=QVBoxLayout(c); l.setSpacing(15)
        l.addWidget(self._h(tr("sec_tunnel")))
        self.tunnel_provider=QComboBox()
        for val,key in TUNNEL_LABELS: self.tunnel_provider.addItem(tr(key), val)
        self.subdomain=QLineEdit()
        self.manual_global=QLineEdit()
        info=QLabel(tr("tunnel_note"))
        info.setObjectName("InfoNote"); info.setWordWrap(True); l.addWidget(info)
        l.addWidget(self._r(tr("lbl_tunnel")+":",self.tunnel_provider))
        l.addWidget(self._r("Fixed Subdomain:",self.subdomain))
        l.addWidget(self._r("Manual Global:",self.manual_global))
        l.addWidget(self._h(tr("sec_bedrock")))
        self.bedrock_enabled=QCheckBox(tr("chk_bedrock"))
        self.bedrock_port=QLineEdit("19132")
        self.bedrock_manual=QLineEdit()
        l.addWidget(self.bedrock_enabled)
        l.addWidget(self._r("Bedrock Port:",self.bedrock_port))
        l.addWidget(self._r("Bedrock Manual:",self.bedrock_manual))
        l.addWidget(self._h(tr("nav_players")))
        self.max_p=QSpinBox(); self.max_p.setRange(1,500)
        self.wl=QCheckBox(tr("chk_whitelist")); self.cracked=QCheckBox(tr("chk_cracked"))
        self.pvp=QCheckBox(tr("chk_pvp")); self.flight=QCheckBox(tr("chk_flight")); self.cmdbl=QCheckBox(tr("chk_cmdblocks"))
        for w in [self._r(tr("lbl_max_players")+":",self.max_p),self.wl,self.cracked,self.pvp,self.flight,self.cmdbl]: l.addWidget(w)
        l.addWidget(self._h(tr("sec_world")))
        self.gm=QComboBox(); self.gm.addItems(["survival","creative","adventure","spectator"])
        self.diff=QComboBox(); self.diff.addItems(["peaceful","easy","normal","hard"])
        self.vd=QSpinBox(); self.vd.setRange(3,32); self.sd=QSpinBox(); self.sd.setRange(3,32)
        self.sp=QSpinBox(); self.sp.setRange(0,1000)
        self.hc=QCheckBox(tr("chk_hardcore")); self.nether=QCheckBox(tr("chk_nether")); self.motd=QLineEdit()
        for w in [self._r(tr("lbl_gamemode")+":",self.gm),self._r(tr("lbl_difficulty")+":",self.diff),
                  self._r(tr("lbl_viewdist")+":",self.vd),self._r(tr("lbl_simdist")+":",self.sd),
                  self._r(tr("lbl_spawnprot")+":",self.sp),self.hc,self.nether,self._r(tr("lbl_motd")+":",self.motd)]: l.addWidget(w)
        l.addWidget(self._h(tr("sec_resources")))
        self.ram_max=QComboBox(); self.ram_max.addItems(["1G","2G","4G","8G","16G","32G"])
        self.java_path=QLineEdit()
        for w in [self._r(tr("lbl_max_ram")+":",self.ram_max),self._r(tr("lbl_custom_java")+":",self.java_path)]: l.addWidget(w)
        save=QPushButton(tr("btn_save")); save.setObjectName("BtnGreen"); save.setFixedHeight(38); save.clicked.connect(self.save); l.addWidget(save)
        l.addStretch()
        scroll.setWidget(c); outer.addWidget(scroll)
    def _h(self,t):
        w=QLabel(t); w.setObjectName("SectionTitle"); return w
    def _r(self,lbl,w):
        r=QWidget(); h=QHBoxLayout(r); h.setContentsMargins(0,0,0,0)
        h.addWidget(QLabel(lbl)); h.addStretch(); w.setFixedWidth(240); h.addWidget(w); return r
    def set_server(self,data):
        self.server=data; sd=data.get("dir",""); pr=load_props(sd)
        tp = data.get("tunnel_provider","bore")
        for i in range(self.tunnel_provider.count()):
            if self.tunnel_provider.itemData(i)==tp:
                self.tunnel_provider.setCurrentIndex(i); break
        self.subdomain.setText(data.get("subdomain",""))
        self.manual_global.setText(data.get("manual_global",""))
        self.bedrock_enabled.setChecked(data.get("bedrock_enabled",True))
        self.bedrock_port.setText(data.get("bedrock_port","19132"))
        self.bedrock_manual.setText(data.get("bedrock_manual",""))
        try: self.max_p.setValue(int(pr.get("max-players",20)))
        except: pass
        self.wl.setChecked(pr.get("white-list","false")=="true")
        self.cracked.setChecked(pr.get("online-mode","true")=="false")
        self.pvp.setChecked(pr.get("pvp","true")=="true")
        self.flight.setChecked(pr.get("allow-flight","false")=="true")
        self.cmdbl.setChecked(pr.get("enable-command-block","false")=="true")
        i=self.gm.findText(pr.get("gamemode","survival")); self.gm.setCurrentIndex(max(0,i))
        i=self.diff.findText(pr.get("difficulty","easy")); self.diff.setCurrentIndex(max(0,i))
        try:
            self.vd.setValue(int(pr.get("view-distance",10)))
            self.sd.setValue(int(pr.get("simulation-distance",10)))
            self.sp.setValue(int(pr.get("spawn-protection",16)))
        except: pass
        self.hc.setChecked(pr.get("hardcore","false")=="true")
        self.nether.setChecked(pr.get("allow-nether","true")=="true")
        self.motd.setText(pr.get("motd","A Minecraft Server"))
        self.ram_max.setCurrentText(data.get("ram_max","2G"))
        self.java_path.setText(data.get("java_path",""))
    def save(self):
        if not self.server: return
        sd=self.server["dir"]; pr=load_props(sd)
        pr.update({"max-players":str(self.max_p.value()),
            "white-list":"true" if self.wl.isChecked() else "false",
            "online-mode":"false" if self.cracked.isChecked() else "true",
            "pvp":"true" if self.pvp.isChecked() else "false",
            "allow-flight":"true" if self.flight.isChecked() else "false",
            "enable-command-block":"true" if self.cmdbl.isChecked() else "false",
            "gamemode":self.gm.currentText(),"difficulty":self.diff.currentText(),
            "view-distance":str(self.vd.value()),"simulation-distance":str(self.sd.value()),
            "spawn-protection":str(self.sp.value()),
            "hardcore":"true" if self.hc.isChecked() else "false",
            "allow-nether":"true" if self.nether.isChecked() else "false",
            "motd":self.motd.text() or "A Minecraft Server"})
        save_props(sd,pr)
        sub = re.sub(r'[^a-z0-9-]','',self.subdomain.text().strip().lower())
        if not sub: sub = f"agc-{random_name(6)}"
        sv=load_servers()
        for s in sv:
            if s["name"]==self.server["name"]:
                s["java_path"]=self.java_path.text().strip()
                s["ram_max"]=self.ram_max.currentText()
                s["tunnel_provider"]=self.tunnel_provider.currentData()
                s["subdomain"]=sub
                s["manual_global"]=self.manual_global.text().strip()
                s["bedrock_enabled"]=self.bedrock_enabled.isChecked()
                s["bedrock_port"]=self.bedrock_port.text()
                s["bedrock_manual"]=self.bedrock_manual.text().strip()
                self.server.update(s); break
        save_servers(sv); QMessageBox.information(self,"OK",tr("msg_saved"))

class LogsTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail; self._raw=""
        l=QVBoxLayout(self)
        sr=QHBoxLayout()
        self.q=QLineEdit(); self.q.setPlaceholderText(tr("ph_search")); self.q.textChanged.connect(self.filt)
        self.lvl=QComboBox(); self.lvl.addItems(["ALL","INFO","WARN","ERROR"]); self.lvl.currentTextChanged.connect(self.filt)
        sr.addWidget(self.q); sr.addWidget(self.lvl); l.addLayout(sr)
        self.out=QPlainTextEdit(); self.out.setObjectName("ConsoleOutput"); self.out.setReadOnly(True); l.addWidget(self.out)
        r=QHBoxLayout()
        for nm,fn,st in [(tr("btn_latest"),"latest","BtnBlue"),(tr("btn_crashes"),"crashes","BtnOrange"),
                          (tr("btn_analyze"),"analyze","BtnGreen"),(tr("btn_folder"),"open","BtnBlue")]:
            b=QPushButton(nm); b.setObjectName(st); b.clicked.connect(getattr(self,fn)); r.addWidget(b)
        r.addStretch(); l.addLayout(r)
    def latest(self):
        if not self.detail.current_server: return
        p=os.path.join(self.detail.current_server["dir"],"logs","latest.log")
        if not os.path.exists(p): self.out.setPlainText(tr("msg_no_log")); return
        self._raw=open(p,"r",encoding="utf-8",errors="ignore").read(); self.filt()
    def crashes(self):
        if not self.detail.current_server: return
        cd=os.path.join(self.detail.current_server["dir"],"crash-reports")
        if not os.path.exists(cd): self.out.setPlainText(tr("msg_no_crashes")); return
        txt=""
        for f in sorted(os.listdir(cd),reverse=True)[:5]:
            txt+=f"\n=== {f} ===\n"+open(os.path.join(cd,f),errors="ignore").read()[:5000]
        self._raw=txt; self.out.setPlainText(txt)
    def filt(self):
        q=self.q.text().lower(); lv=self.lvl.currentText()
        lines=self._raw.split("\n")
        if lv!="ALL": lines=[ln for ln in lines if lv in ln.upper()]
        if q: lines=[ln for ln in lines if q in ln.lower()]
        self.out.setPlainText("\n".join(lines))
    def analyze(self):
        if not self._raw: return
        t=self._raw.lower(); f=[]
        for k,v in [("outofmemoryerror","OOM"),("already in use",tr("iss_port")),
                     ("requires running the server with java",tr("iss_java"))]:
            if k in t: f.append(f"[!] {v}")
        QMessageBox.information(self,tr("btn_analyze"),"\n".join(f) if f else tr("msg_no_issues"))
    def open(self):
        if not self.detail.current_server: return
        p=os.path.join(self.detail.current_server["dir"],"logs")
        if os.path.exists(p):
            if os.name=='nt': os.startfile(p)
            else: subprocess.Popen(["xdg-open",p])

class FilesTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail; self.cur=None; self.cf=None
        l=QVBoxLayout(self)
        self.pth=QLabel("/"); l.addWidget(self.pth)
        sp=QSplitter(Qt.Orientation.Horizontal)
        self.files=QListWidget(); self.files.itemDoubleClicked.connect(self.open)
        self.editor=QPlainTextEdit()
        sp.addWidget(self.files); sp.addWidget(self.editor); sp.setSizes([300,700])
        l.addWidget(sp)
        r=QHBoxLayout()
        for nm,fn,st in [(tr("btn_up"),"up","BtnBlue"),(tr("btn_save"),"save","BtnGreen"),(tr("btn_refresh"),"refresh","BtnOrange")]:
            b=QPushButton(nm); b.setObjectName(st); b.clicked.connect(getattr(self,fn)); r.addWidget(b)
        r.addStretch(); l.addLayout(r)
    def set_server(self,d):
        if d: self.cur=d.get("dir"); self.refresh()
    def refresh(self):
        if not self.cur: return
        self.pth.setText(self.cur); self.files.clear()
        try:
            for it in sorted(os.listdir(self.cur)):
                self.files.addItem(f"{'[D]' if os.path.isdir(os.path.join(self.cur,it)) else '[F]'} {it}")
        except: pass
    def open(self,it):
        n=it.text()[4:]; fp=os.path.join(self.cur,n)
        if os.path.isdir(fp): self.cur=fp; self.refresh()
        else:
            try:
                if os.path.getsize(fp)>2_000_000: return
                self.editor.setPlainText(open(fp,"r",encoding="utf-8",errors="ignore").read()); self.cf=fp
            except: pass
    def up(self):
        p=os.path.dirname(self.cur) if self.cur else None
        if p and len(p)>=len(os.path.abspath(SERVERS_DIR)): self.cur=p; self.refresh()
    def save(self):
        if not self.cf: return
        try:
            os.makedirs(BACKUPS_DIR,exist_ok=True)
            ts=datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            shutil.copy2(self.cf,os.path.join(BACKUPS_DIR,f"bak_{os.path.basename(self.cf)}_{ts}"))
            open(self.cf,"w",encoding="utf-8").write(self.editor.toPlainText())
            QMessageBox.information(self,"OK",tr("msg_saved"))
        except Exception as e: QMessageBox.critical(self,tr("err_error"),str(e))

class SchedulerTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        l=QVBoxLayout(self)
        self.lst=QListWidget(); l.addWidget(self.lst)
        r=QHBoxLayout()
        self.t=QLineEdit(); self.t.setPlaceholderText(tr("ph_time"))
        self.c=QLineEdit(); self.c.setPlaceholderText(tr("lbl_command"))
        ad=QPushButton(tr("btn_add")); ad.setObjectName("BtnGreen"); ad.clicked.connect(self.add)
        rm=QPushButton(tr("btn_remove")); rm.setObjectName("BtnRed"); rm.clicked.connect(self.rem)
        for w in [self.t,self.c,ad,rm]: r.addWidget(w)
        l.addLayout(r); l.addStretch()
    def add(self):
        t=self.t.text().strip(); c=self.c.text().strip()
        if not t or not c: return
        self.detail.current_server.setdefault("schedule",[]).append({"time":t,"cmd":c}); self.save(); self.refresh()
    def rem(self):
        i=self.lst.currentRow()
        if i<0: return
        ts=self.detail.current_server.get("schedule",[])
        if i<len(ts): del ts[i]
        self.save(); self.refresh()
    def save(self):
        sv=load_servers()
        for s in sv:
            if s["name"]==self.detail.current_server["name"]:
                s["schedule"]=self.detail.current_server.get("schedule",[]); break
        save_servers(sv)
    def refresh(self):
        self.lst.clear()
        if not self.detail.current_server: return
        for t in self.detail.current_server.get("schedule",[]): self.lst.addItem(f"{t['time']} -> {t['cmd']}")
    def check(self):
        if self.detail.process.state()!=QProcess.ProcessState.Running: return
        now=datetime.datetime.now().strftime("%H:%M")
        for t in self.detail.current_server.get("schedule",[]):
            if t["time"]==now and not t.get("_done"):
                for c in t["cmd"].split("|"): self.detail.send_command(c.strip())
                t["_done"]=True
            elif t["time"]!=now: t.pop("_done",None)

class ActivityTab(QWidget):
    def __init__(self):
        super().__init__()
        l=QVBoxLayout(self)
        self.t=QTableWidget(0,4); self.t.setHorizontalHeaderLabels([tr("col_time"),tr("col_server"),tr("col_action"),tr("col_details")])
        self.t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        l.addWidget(self.t)
        rf=QPushButton(tr("btn_refresh")); rf.setObjectName("BtnBlue"); rf.clicked.connect(self.refresh); l.addWidget(rf)
    def refresh(self):
        a=load_json(ACTIVITY_FILE,[])
        self.t.setRowCount(len(a))
        for i,x in enumerate(a):
            for j,k in enumerate(["time","server","action","details"]):
                self.t.setItem(i,j,QTableWidgetItem(str(x.get(k,""))))

class NetworkingTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        l=QVBoxLayout(self); l.setContentsMargins(20,20,20,20)
        self.info=QLabel(); self.info.setObjectName("PanelText"); self.info.setWordWrap(True); l.addWidget(self.info)
        self.ginfo=QLabel(); self.ginfo.setObjectName("InfoNote")
        self.ginfo.setWordWrap(True); l.addWidget(self.ginfo)
        self.binfo=QLabel(); self.binfo.setObjectName("InfoNote")
        self.binfo.setWordWrap(True); l.addWidget(self.binfo)
        l.addStretch(); self.refresh()
    def refresh(self):
        if not self.detail.current_server: return
        p=self.detail.current_server.get("port","25565"); ip=get_local_ip()
        run=self.detail.process.state()==QProcess.ProcessState.Running
        bp = self.detail.current_server.get("bedrock_port","19132")
        tp = tunnel_label(self.detail.current_server.get("tunnel_provider","bore"))
        self.info.setText(f"<b>{tr('net_java_port')}:</b> {p}<br><b>{tr('net_lan')}:</b> {ip}:{p}<br><b>{tr('net_bedrock_port')}:</b> {bp} (UDP)<br><b>{tr('net_mode')}:</b> {tp}<br><b>{tr('net_status')}:</b> {'🟢' if run else '🔴'}")
        mg=self.detail.current_server.get("manual_global","").strip()
        ga=self.detail.global_addr or mg
        if ga:
            self.ginfo.setText(f"🌍 <b>{tr('net_global')}:</b> {ga}")
        else:
            self.ginfo.setText(tr("ginfo_pending"))
        bm = self.detail.current_server.get("bedrock_manual","").strip()
        if bm:
            self.binfo.setText(f"📱 <b>{tr('net_bedrock')}:</b> {bm}:{bp}")
        elif ga:
            host = ga.split(":")[0] if ":" in ga else ga
            self.binfo.setText(f"📱 <b>{tr('net_bedrock')}:</b> {host}:{bp} (UDP)")
        else:
            self.binfo.setText(f"📱 {tr('net_bedrock')} {bp} (UDP)")

class CloudTab(QWidget):
    def __init__(self,detail):
        super().__init__(); self.detail=detail
        l=QVBoxLayout(self); l.setSpacing(12)
        self.status=QLabel(); self.status.setObjectName("InfoNote")
        l.addWidget(self.status)
        card=QFrame(); card.setObjectName("PanelCard"); f=QFormLayout(card); f.setContentsMargins(16,16,16,16)
        cfg=load_config()
        self.en=QCheckBox(tr("chk_enable")); self.en.setChecked(cfg.get("cloud_enabled",False))
        self.rem=QLineEdit(cfg.get("cloud_remote","gdrive"))
        self.folder=QLineEdit(cfg.get("cloud_folder","AGCraftNode_Backups"))
        self.auto=QCheckBox(tr("chk_auto_backup")); self.auto.setChecked(cfg.get("auto_backup_on_stop",True))
        f.addRow(self.en); f.addRow("Remote:",self.rem); f.addRow(tr("btn_folder")+":",self.folder); f.addRow(self.auto)
        l.addWidget(card)
        r=QHBoxLayout()
        cf=QPushButton(tr("btn_configure")); cf.setObjectName("BtnBlue"); cf.clicked.connect(self.config_rclone)
        sv=QPushButton(tr("btn_save")); sv.setObjectName("BtnGreen"); sv.clicked.connect(self.save)
        for b in [cf,sv]: r.addWidget(b)
        l.addLayout(r); l.addStretch()
        self.refresh()
    def refresh(self):
        if rclone_available():
            self.status.setText(tr("rclone_ok"))
        else:
            self.status.setText(tr("rclone_missing"))
    def config_rclone(self):
        rc=find_tool("rclone")
        if not rc: QMessageBox.warning(self,"rclone",tr("msg_install_rclone")); return
        try:
            if os.name=='nt': subprocess.Popen([rc,"config"],creationflags=subprocess.CREATE_NEW_CONSOLE)
            else: subprocess.Popen([rc,"config"])
        except Exception as e: QMessageBox.critical(self,tr("err_error"),str(e))
    def save(self):
        cfg=load_config()
        cfg["cloud_enabled"]=self.en.isChecked()
        cfg["cloud_remote"]=self.rem.text().strip()
        cfg["cloud_folder"]=self.folder.text().strip()
        cfg["auto_backup_on_stop"]=self.auto.isChecked()
        save_config(cfg); QMessageBox.information(self,"OK",tr("msg_saved"))

class SettingsTab(QWidget):
    theme_changed=pyqtSignal(str)
    def __init__(self):
        super().__init__()
        l=QVBoxLayout(self); l.setContentsMargins(30,30,30,30); l.setSpacing(15)
        cfg=load_config()
        l.addWidget(self._h(tr("sec_appearance")))
        af=QFormLayout()
        self.theme=QComboBox(); self.theme.addItem(tr("theme_dark"),"dark"); self.theme.addItem(tr("theme_light"),"light")
        i=self.theme.findData(cfg.get("theme","dark")); self.theme.setCurrentIndex(max(0,i))
        self.lang=QComboBox(); self.lang.addItem(tr("lang_en"),"en"); self.lang.addItem(tr("lang_ur"),"ur")
        i=self.lang.findData(cfg.get("language","en")); self.lang.setCurrentIndex(max(0,i))
        af.addRow(tr("lbl_theme")+":",self.theme); af.addRow(tr("lbl_language")+":",self.lang)
        l.addLayout(af)
        l.addWidget(self._h(tr("sec_dictator")))
        df=QFormLayout()
        self.dn=QCheckBox(tr("chk_dictator")); self.dn.setChecked(cfg.get("dictator_enabled",True))
        self.mm=QCheckBox(tr("chk_manual")); self.mm.setChecked(cfg.get("manual_mode",False))
        df.addRow(self.dn); df.addRow(self.mm); l.addLayout(df)
        l.addWidget(self._h(tr("sec_startup")))
        sf=QFormLayout()
        self.aw=QCheckBox(tr("chk_start_win")); self.aw.setChecked(cfg.get("start_with_windows",False))
        sf.addRow(self.aw); l.addLayout(sf)
        sv=QPushButton(tr("btn_save")); sv.setObjectName("BtnGreen"); sv.setFixedHeight(38); sv.clicked.connect(self.save); l.addWidget(sv)
        l.addStretch()
    def _h(self,t):
        w=QLabel(t); w.setObjectName("SectionTitle"); return w
    def save(self):
        cfg=load_config()
        old_theme=cfg.get("theme","dark"); old_lang=cfg.get("language","en")
        cfg["theme"]=self.theme.currentData()
        cfg["language"]=self.lang.currentData()
        cfg["dictator_enabled"]=self.dn.isChecked()
        cfg["manual_mode"]=self.mm.isChecked()
        cfg["start_with_windows"]=self.aw.isChecked()
        save_config(cfg)
        try:
            if os.name=='nt':
                sp=os.path.join(os.environ.get("APPDATA",""),"Microsoft","Windows","Start Menu","Programs","Startup","AGCraftNode.bat")
                if self.aw.isChecked():
                    with open(sp,"w") as f: f.write(f'@echo off\ncd /d "{os.getcwd()}"\nstart "" pythonw main.py\n')
                elif os.path.exists(sp): os.remove(sp)
        except: pass
        if cfg["language"]!=old_lang:
            restart_app(); return
        QMessageBox.information(self,"OK",tr("msg_saved"))
        if cfg["theme"]!=old_theme:
            app=QApplication.instance()
            if app: apply_theme(app)
        self.theme_changed.emit(cfg["theme"])

class ToolsTab(QWidget):
    def __init__(self, app_window=None):
        super().__init__()
        self.app_window = app_window
        outer=QVBoxLayout(self); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        inner=QWidget()
        l=QVBoxLayout(inner); l.setContentsMargins(30,30,30,30); l.setSpacing(15)
        l.addWidget(self._h(tr("sec_tunnel_tools")))
        info=QLabel(tr("net_info")); info.setObjectName("InfoNote"); info.setWordWrap(True); l.addWidget(info)
        self.bstat=QLabel(); l.addWidget(self.bstat)
        self.bbtn=QPushButton(tr("btn_install_bore")); self.bbtn.setObjectName("GreenBtn")
        self.bbtn.clicked.connect(self.install_bore); l.addWidget(self.bbtn)
        self.sshd=QLabel(); l.addWidget(self.sshd)
        l.addWidget(self._h(tr("sec_cloud")))
        self.rstat=QLabel(); l.addWidget(self.rstat)
        self.rbtn=QPushButton(tr("btn_install_rclone")); self.rbtn.setObjectName("WarnBtn")
        self.rbtn.clicked.connect(self.install_rclone); l.addWidget(self.rbtn)
        l.addWidget(self._h(tr("sec_java")))
        self.jstat=QLabel(); l.addWidget(self.jstat)
        self.jbtn=QPushButton(f"{tr('btn_install_java')} {REQUIRED_JAVA}"); self.jbtn.setObjectName("WarnBtn")
        self.jbtn.clicked.connect(self.install_java); l.addWidget(self.jbtn)
        l.addWidget(self._h(tr("sec_info")))
        info2=QLabel(tr("info_catalog").format(n=len(POPULAR_PLUGINS)))
        info2.setObjectName("InfoNote"); info2.setWordWrap(True); l.addWidget(info2)
        l.addWidget(self._h(tr("sec_log")))
        self.log=QTextEdit(); self.log.setReadOnly(True); l.addWidget(self.log)
        l.addStretch(); self.refresh_status()
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(inner)
        outer.addWidget(scroll)
    def _h(self,t):
        w=QLabel(t); w.setObjectName("SectionTitle"); return w
    def log_msg(self,m): self.log.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] {m}")
    def refresh_status(self):
        def setlbl(lbl, ok, name):
            lbl.setText(f"{name}: {tr('tool_ready') if ok else tr('tool_na')}")
            lbl.setObjectName("StatusOnline" if ok else "StatusOffline")
            lbl.setStyleSheet(""); lbl.style().unpolish(lbl); lbl.style().polish(lbl)
        setlbl(self.bstat, bore_available(), "bore (dynamic)"); self.bbtn.setEnabled(not bore_available())
        setlbl(self.sshd, serveo_available(), "SSH client (Windows built-in)")
        setlbl(self.rstat, rclone_available(), "rclone"); self.rbtn.setEnabled(not rclone_available())
        setlbl(self.jstat, find_java(REQUIRED_JAVA) is not None, f"Java {REQUIRED_JAVA}"); self.jbtn.setEnabled(find_java(REQUIRED_JAVA) is None)
    def _dlg(self,title):
        dlg=QDialog(self); dlg.setWindowTitle(title); dlg.setFixedSize(400,120)
        l=QVBoxLayout(dlg); pb=QProgressBar(); lbl=QLabel(title)
        l.addWidget(lbl); l.addWidget(pb); dlg.show()
        return dlg,pb
    def _run(self, thread_cls, name):
        dlg,pb=self._dlg(tr("msg_installing_name").format(name=name))
        th=thread_cls(); th.progress.connect(pb.setValue)
        if hasattr(th,'log'): th.log.connect(self.log_msg)
        def done(ok,msg):
            dlg.close(); self.log_msg(msg)
            if not ok: QMessageBox.critical(self,name,msg)
            self.refresh_status()
        th.finished.connect(done); self._t=th; th.start()
    def install_bore(self): self._run(BoreInstaller,"bore")
    def install_rclone(self): self._run(RcloneInstaller,"rclone")
    def install_java(self):
        dlg,pb=self._dlg(f"Java {REQUIRED_JAVA}")
        th=JavaInstaller(REQUIRED_JAVA); th.progress.connect(pb.setValue); th.log.connect(self.log_msg)
        def done(ok,msg):
            dlg.close(); self.log_msg(msg); self.refresh_status()
        th.finished.connect(done); self._t=th; th.start()

class ServerDetailPage(QWidget):
    def __init__(self, app_window=None):
        super().__init__()
        self.app_window = app_window
        self.current_server=None; self.eula_shown=False; self.restart_after_eula=False
        self.restart_after_stop=False; self.start_time=None; self.global_addr=None
        self.process=QProcess(self)
        self.process.readyReadStandardOutput.connect(self.on_stdout)
        self.process.readyReadStandardError.connect(self.on_stderr)
        self.process.stateChanged.connect(self.on_state)
        ml=QHBoxLayout(self); ml.setContentsMargins(0,0,0,0); ml.setSpacing(0)
        sb=QFrame(); sb.setObjectName("Sidebar"); sb.setFixedWidth(200)
        sl=QVBoxLayout(sb); sl.setContentsMargins(0,0,0,0); sl.setSpacing(0)
        self.sn=QLabel("Server"); self.sn.setObjectName("SideName")
        sl.addWidget(self.sn)
        back=QPushButton(tr("nav_back")); back.setObjectName("SideBack"); back.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        back.clicked.connect(self.go_back); sl.addWidget(back)
        self.nav={}
        self.nav_items=[("Dashboard","nav_dashboard"),("Console","nav_console"),("Players","nav_players"),("Worlds","nav_worlds"),
            ("Backups","nav_backups"),("Plugins","nav_plugins"),("Performance","nav_performance"),("Options","nav_options"),
            ("Logs","nav_logs"),("Files","nav_files"),("Scheduler","nav_scheduler"),("Networking","nav_networking"),
            ("Cloud","nav_cloud"),("Activity","nav_activity")]
        for key,tkey in self.nav_items:
            b=QPushButton(f"  {tr(tkey)}"); b.setObjectName("SidebarBtn"); b.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            b.clicked.connect(lambda _,n=key: self.switch(n)); sl.addWidget(b); self.nav[key]=b
        sl.addStretch(); ml.addWidget(sb)
        self.stack=QStackedWidget()
        self.dash=QWidget(); dl=QVBoxLayout(self.dash); dl.setSpacing(12)
        addr_box=QFrame(); addr_box.setObjectName("PanelCard")
        ab=QVBoxLayout(addr_box); ab.setSpacing(10)
        self.srv_name=QLabel(""); self.srv_name.setObjectName("AddrTitle")
        self.srv_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ab.addWidget(self.srv_name)
        local_row=QHBoxLayout()
        local_lbl=QLabel(tr("lbl_local")); local_lbl.setObjectName("AddrLabel"); local_lbl.setFixedWidth(75)
        self.local_value=QLabel("-"); self.local_value.setObjectName("AddrValue")
        self.local_value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.local_copy=QPushButton(tr("btn_copy")); self.local_copy.setObjectName("CopyBtn")
        self.local_copy.setFixedWidth(60); self.local_copy.clicked.connect(self.copy_local)
        local_row.addWidget(local_lbl); local_row.addWidget(self.local_value,1); local_row.addWidget(self.local_copy)
        ab.addLayout(local_row)
        global_row=QHBoxLayout()
        global_lbl=QLabel(tr("lbl_java")); global_lbl.setObjectName("AddrLabel"); global_lbl.setFixedWidth(75)
        self.global_value=QLabel("-"); self.global_value.setObjectName("AddrAccent")
        self.global_value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.global_copy=QPushButton(tr("btn_copy")); self.global_copy.setObjectName("CopyBtn")
        self.global_copy.setFixedWidth(60); self.global_copy.clicked.connect(self.copy_global)
        global_row.addWidget(global_lbl); global_row.addWidget(self.global_value,1); global_row.addWidget(self.global_copy)
        ab.addLayout(global_row)
        bedrock_row=QHBoxLayout()
        bedrock_lbl=QLabel(tr("lbl_bedrock")); bedrock_lbl.setObjectName("AddrLabel"); bedrock_lbl.setFixedWidth(75)
        self.bedrock_value=QLabel("-"); self.bedrock_value.setObjectName("AddrValue")
        self.bedrock_value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.bedrock_copy=QPushButton(tr("btn_copy")); self.bedrock_copy.setObjectName("CopyBtn")
        self.bedrock_copy.setFixedWidth(60); self.bedrock_copy.clicked.connect(self.copy_bedrock)
        bedrock_row.addWidget(bedrock_lbl); bedrock_row.addWidget(self.bedrock_value,1); bedrock_row.addWidget(self.bedrock_copy)
        ab.addLayout(bedrock_row)
        dl.addWidget(addr_box)
        self.status=QLabel(tr("st_offline")); self.status.setObjectName("StatusOffline")
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dl.addWidget(self.status)
        g=QGridLayout(); g.setSpacing(12)
        self.st_p=self._c(tr("col_players"),"0/0"); self.st_u=self._c(tr("col_uptime"),"-")
        self.st_t=self._c("TPS","-"); self.st_r=self._c(tr("col_ram"),"-")
        g.addWidget(self.st_p[0],0,0); g.addWidget(self.st_u[0],0,1); g.addWidget(self.st_t[0],0,2); g.addWidget(self.st_r[0],0,3)
        dl.addLayout(g)
        br=QHBoxLayout(); br.setAlignment(Qt.AlignmentFlag.AlignCenter); br.setSpacing(12)
        self.dlj=QPushButton(tr("btn_dl_jar")); self.dlj.setObjectName("WarnBtn"); self.dlj.clicked.connect(self.dl_jar)
        self.dlv=QPushButton(f"Java {REQUIRED_JAVA}"); self.dlv.setObjectName("PurpleBtn"); self.dlv.clicked.connect(self.dl_java)
        self.start=QPushButton(tr("btn_start")); self.start.setObjectName("StartBtn"); self.start.clicked.connect(self.toggle)
        self.restart=QPushButton(tr("btn_restart")); self.restart.setObjectName("WarnBtn"); self.restart.clicked.connect(self.restart_fn)
        for b in [self.dlj,self.dlv,self.start,self.restart]: br.addWidget(b)
        dl.addLayout(br); dl.addStretch()
        self.console=ConsoleWidget(self.process)
        self.players_t=PlayersTab(self); self.worlds=WorldsTab(self); self.backups=BackupTab(self)
        self.plugins=PluginsTab(self); self.perf=PerformanceTab(self); self.options=OptionsTab(self)
        self.logs=LogsTab(self); self.files=FilesTab(self); self.sched=SchedulerTab(self)
        self.net=NetworkingTab(self); self.cloud=CloudTab(self); self.act=ActivityTab()
        for w in [self.dash,self.console,self.players_t,self.worlds,self.backups,self.plugins,
                  self.perf,self.options,self.logs,self.files,self.sched,self.net,self.cloud,self.act]:
            self.stack.addWidget(w)
        ml.addWidget(self.stack); self.switch("Dashboard")
        self.t1=QTimer(self); self.t1.timeout.connect(self.tick); self.t1.start(1000)
        self.t2=QTimer(self); self.t2.timeout.connect(self.check_sched); self.t2.start(30000)
        self.t3=QTimer(self); self.t3.timeout.connect(self.refresh_players); self.t3.start(15000)
    def _c(self,lbl,v):
        c=QFrame(); c.setObjectName("StatCard"); l=QVBoxLayout(c)
        vl=QLabel(v); vl.setObjectName("StatValue"); vl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ll=QLabel(lbl); ll.setObjectName("StatLabel"); ll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        l.addWidget(vl); l.addWidget(ll); return (c,vl)
    def refresh_players(self):
        try:
            if self.current_server and self.process.state()==QProcess.ProcessState.Running:
                self.players_t.refresh_all()
        except: pass
    def go_back(self):
        if self.app_window: self.app_window.home()
    def copy_local(self):
        txt=self.local_value.text()
        if txt and txt!="-":
            QApplication.clipboard().setText(txt)
            self.local_copy.setText("✓"); QTimer.singleShot(1500, lambda: self.local_copy.setText(tr("btn_copy")))
    def copy_global(self):
        txt=self.global_value.text()
        if txt and txt not in ("-",tr("st_pending"),tr("tunnel_off")):
            QApplication.clipboard().setText(txt)
            self.global_copy.setText("✓"); QTimer.singleShot(1500, lambda: self.global_copy.setText(tr("btn_copy")))
        else:
            QMessageBox.information(self,tr("lbl_java"),tr("st_pending"))
    def copy_bedrock(self):
        txt=self.bedrock_value.text()
        if txt and txt!="-":
            QApplication.clipboard().setText(txt)
            self.bedrock_copy.setText("✓"); QTimer.singleShot(1500, lambda: self.bedrock_copy.setText(tr("btn_copy")))
    def check_sched(self):
        if self.current_server:
            try: self.sched.check()
            except: pass
    def switch(self,name):
        for n,b in self.nav.items():
            b.setObjectName("SidebarBtnActive" if n==name else "SidebarBtn")
            b.setStyleSheet(""); b.style().unpolish(b); b.style().polish(b)
        keys=[k for k,_ in self.nav_items]
        i=keys.index(name)
        self.stack.setCurrentIndex(i)
        if name=="Options" and self.current_server: self.options.set_server(self.current_server)
        if name=="Files" and self.current_server: self.files.set_server(self.current_server)
        if name=="Scheduler": self.sched.refresh()
        if name=="Activity": self.act.refresh()
        if name=="Worlds": self.worlds.refresh()
        if name=="Backups": self.backups.refresh()
        if name=="Plugins": self.plugins.refresh_inst(); self.plugins.refresh_catalog()
        if name=="Performance": self.perf.refresh_disk()
        if name=="Logs": self.logs.latest()
        if name=="Networking": self.net.refresh()
        if name=="Cloud": self.cloud.refresh()
        if name=="Players": self.players_t.refresh_all()
    def set_server(self,data):
        self.current_server=data; self.eula_shown=False; self.restart_after_eula=False
        self.sn.setText(data["name"]); self.srv_name.setText(data["name"])
        ip=get_local_ip(); p=data.get("port","25565")
        self.local_value.setText(f"{ip}:{p}")
        mg=data.get("manual_global","").strip()
        if mg:
            self.global_addr=mg; self.global_value.setText(mg)
        else:
            tp = data.get("tunnel_provider","bore")
            if tp == "serveo":
                sub = data.get("subdomain","")
                self.global_value.setText(f"{sub}.serveo.net:{p} ({tr('st_starting').lower()})")
            else:
                self.global_value.setText(tr("st_pending"))
        bp = data.get("bedrock_port","19132")
        bm = data.get("bedrock_manual","").strip()
        if bm:
            self.bedrock_value.setText(f"{bm}:{bp}")
        elif mg:
            host = mg.split(":")[0] if ":" in mg else mg
            self.bedrock_value.setText(f"{host}:{bp}")
        else:
            tp = data.get("tunnel_provider","bore")
            if tp == "serveo":
                sub = data.get("subdomain","")
                self.bedrock_value.setText(f"{sub}.serveo.net:{bp}")
            else:
                self.bedrock_value.setText(f"{ip}:{bp}")
        self.console.clear(); self.console.append(f"=== {data['name']} ===")
        jar=os.path.join(data.get("dir",""),"server.jar")
        self.dlj.setText(tr("jar_ready") if os.path.exists(jar) else tr("btn_dl_jar"))
        self.dlj.setEnabled(not os.path.exists(jar))
        jo=find_java(REQUIRED_JAVA)
        self.dlv.setText(tr("java_ready") if jo else tr("btn_dl_java"))
        self.dlv.setEnabled(not jo)
        if hasattr(self,'options'): self.options.set_server(data)
        if hasattr(self,'net'): self.net.refresh()
        if hasattr(self,'players_t'): self.players_t.refresh_all()
        if hasattr(self,'plugins'): self.plugins.refresh_catalog()
    def dl_jar(self):
        if not self.current_server: return
        sw=self.current_server.get("software","PaperMC"); v=self.current_server.get("version","latest")
        sd=self.current_server["dir"]; os.makedirs(sd,exist_ok=True)
        dlg=QDialog(self); dlg.setWindowTitle("Download"); dlg.setFixedSize(320,100)
        l=QVBoxLayout(dlg); pb=QProgressBar(); l.addWidget(pb); dlg.show()
        dl=VanillaDownloader(sd,v) if sw=="Vanilla" else (PurpurDownloader(sd,v) if sw=="Purpur" else PaperDownloader(sd,v))
        dl.progress.connect(pb.setValue)
        def done(ok,msg):
            dlg.close(); QMessageBox.information(self,tr("msg_result"),msg)
            if ok: self.dlj.setText(tr("jar_ready")); self.dlj.setEnabled(False)
        dl.finished.connect(done); self._j=dl; dl.start()
    def dl_java(self):
        dlg=QDialog(self); dlg.setWindowTitle("Java"); dlg.setFixedSize(320,100)
        l=QVBoxLayout(dlg); pb=QProgressBar(); l.addWidget(pb); dlg.show()
        dl=JavaInstaller(REQUIRED_JAVA); dl.progress.connect(pb.setValue)
        def done(ok,msg):
            dlg.close(); QMessageBox.information(self,tr("msg_result"),msg)
            if ok: self.dlv.setText(tr("java_ready")); self.dlv.setEnabled(False)
        dl.finished.connect(done); self._v=dl; dl.start()
    def toggle(self):
        if self.process.state()==QProcess.ProcessState.NotRunning: self.start_server()
        else: self.stop_server()
    def start_server(self):
        if not self.current_server: return
        sd=self.current_server["dir"]; jar=os.path.join(sd,"server.jar")
        if not os.path.exists(jar): QMessageBox.warning(self,tr("err_missing"),tr("jar_not_found")); return
        self.console.append("=== Auto-fix ===")
        locked=auto_pre_start(sd, log_cb=self.console.append)
        if locked and QMessageBox.question(self,tr("locks_title"),tr("locks_msg").format(n=locked))!=QMessageBox.StandardButton.Yes: return
        cj=self.current_server.get("java_path","").strip()
        cmd=cj if cj and os.path.exists(cj) else find_java(REQUIRED_JAVA)
        if not cmd: QMessageBox.critical(self,tr("err_error"),tr("java_required").format(v=REQUIRED_JAVA)); return
        self.status.setText(tr("st_starting")); self.status.setObjectName("StatusStarting")
        self.status.setStyleSheet(""); self.status.style().unpolish(self.status); self.status.style().polish(self.status)
        rm=self.current_server.get("ram_min","1G"); rx=self.current_server.get("ram_max","2G")
        args=[f"-Xms{rm}",f"-Xmx{rx}","-jar","server.jar","nogui"]
        self.process.setWorkingDirectory(os.path.abspath(sd))
        self.process.start(cmd,args)
        log_activity("Start",self.current_server["name"]); self.start_time=time.time()
        if self.current_server.get("bedrock_enabled",False) and self.app_window:
            QTimer.singleShot(10000, self.app_window.ensure_geyser)
        cfg=load_config()
        tp=self.current_server.get("tunnel_provider","bore")
        if tp != "none" and cfg.get("auto_tunnel_on_start", True) and self.app_window:
            QTimer.singleShot(3000, self.app_window.start_tunnel)
    def on_stdout(self):
        d=self.process.readAllStandardOutput().data().decode('utf-8',errors='ignore')
        if not d: return
        self.console.append(d); self.check_eula(d)
        m=re.search(r"TPS from last 1m, 5m, 15m: ([\d.]+)",d)
        if m:
            tps=float(m.group(1)); self.st_t[1].setText(f"{tps:.1f}"); self.perf.update_tps(tps)
        self.players_t.parse_online(d)
        if ("Geyser" in d or "geyser" in d) and ("Enabling" in d or "Started" in d or "Loading" in d or "Done" in d):
            if self.current_server and self.current_server.get("bedrock_enabled",False):
                bp = self.current_server.get("bedrock_port","19132")
                sd = self.current_server["dir"]
                QTimer.singleShot(5000, lambda: self._edit_geyser_async(sd, bp))
    def _edit_geyser_async(self, sd, bp):
        n = edit_geyser_config(sd, bp)
        if n: self.console.append(f"[Geyser] Config auto-edited")
    def on_stderr(self):
        d=self.process.readAllStandardError().data().decode('utf-8',errors='ignore')
        if d: self.console.append(f"[ERR] {d}"); self.check_eula(d)
    def check_eula(self,d):
        if self.eula_shown: return
        if "eula.txt" in d.lower() or "agree to the eula" in d.lower():
            self.eula_shown=True; QTimer.singleShot(1500,self.ask_eula)
    def ask_eula(self):
        if QMessageBox.question(self,tr("eula_title"),tr("eula_msg"))==QMessageBox.StandardButton.Yes:
            write_eula(self.current_server["dir"]); self.restart_after_eula=True
            if self.process.state()==QProcess.ProcessState.NotRunning: QTimer.singleShot(500,self.start_server)
    def on_state(self,s):
        if s==QProcess.ProcessState.Running:
            self.status.setText(tr("st_online")); self.status.setObjectName("StatusOnline")
            self.status.setStyleSheet(""); self.status.style().unpolish(self.status); self.status.style().polish(self.status)
            self.start.setText(tr("btn_stop")); self.start.setObjectName("StopBtn")
            self.start.setStyleSheet(""); self.start.style().unpolish(self.start); self.start.style().polish(self.start)
            if not self.start_time: self.start_time=time.time()
        elif s==QProcess.ProcessState.NotRunning:
            self.status.setText(tr("st_offline")); self.status.setObjectName("StatusOffline")
            self.status.setStyleSheet(""); self.status.style().unpolish(self.status); self.status.style().polish(self.status)
            self.start.setText(tr("btn_start")); self.start.setObjectName("StartBtn")
            self.start.setStyleSheet(""); self.start.style().unpolish(self.start); self.start.style().polish(self.start)
            self.start_time=None; self.st_u[1].setText("-")
            if self.app_window: self.app_window.stop_tunnel()
            if self.restart_after_eula: self.restart_after_eula=False; QTimer.singleShot(500,self.start_server)
            elif self.restart_after_stop: self.restart_after_stop=False; QTimer.singleShot(1000,self.start_server)
    def stop_server(self):
        if self.process.state()==QProcess.ProcessState.Running:
            self.process.write(b"stop\n")
        if self.app_window: self.app_window.stop_tunnel()
    def restart_fn(self):
        if self.process.state()==QProcess.ProcessState.Running:
            self.restart_after_stop=True; self.process.write(b"stop\n")
        else: self.start_server()
    def send_command(self,cmd):
        if self.process.state()==QProcess.ProcessState.Running: self.process.write(f"{cmd}\n".encode())
    def tick(self):
        if self.start_time and self.process.state()==QProcess.ProcessState.Running:
            s=int(time.time()-self.start_time)
            h=s//3600; m=(s%3600)//60
            self.st_u[1].setText(f"{h}h {m}m"); self.perf.update_uptime(s)
    def update_player_count(self,n):
        try: mx=load_props(self.current_server["dir"]).get("max-players","20")
        except: mx="20"
        self.st_p[1].setText(f"{n}/{mx}")
    def set_global_addr(self, addr, bedrock_port=None):
        self.global_addr=addr
        self.global_value.setText(addr)
        if bedrock_port:
            host = addr.split(":")[0] if ":" in addr else addr
            self.bedrock_value.setText(f"{host}:{bedrock_port}")
        if self.current_server:
            sv=load_servers()
            for s in sv:
                if s["name"]==self.current_server["name"]:
                    s["manual_global"]=addr; break
            save_servers(sv)

def make_splash():
    pm=QPixmap(600,350); pm.fill(QColor("#121212"))
    sp=QSplashScreen(pm)
    sp.showMessage(f"{APP_NAME}\nv{APP_VERSION}\n\n{len(POPULAR_PLUGINS)} plugins catalog loaded...",Qt.AlignmentFlag.AlignCenter,QColor("#4FC3F7"))
    return sp

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg=load_config()
        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        scr=QApplication.primaryScreen(); avh=scr.availableGeometry().height() if scr else 1080
        self.resize(1400,min(850,avh-110))
        self.bore=BoreDictator(); self.bore.log.connect(self.tunnel_log); self.bore.address_found.connect(self.bore_address)
        self.serveo=ServeoDictator(); self.serveo.log.connect(self.tunnel_log); self.serveo.address_found.connect(self.serveo_address)
        self.playit=PlayitDictator(); self.playit.log.connect(self.tunnel_log); self.playit.address_found.connect(self.playit_address); self.playit.needs_manual.connect(self.playit_manual)
        cw=QWidget(); self.setCentralWidget(cw)
        ml=QVBoxLayout(cw); ml.setContentsMargins(0,0,0,0); ml.setSpacing(0)
        hdr=QFrame(); hdr.setObjectName("TopHeader"); hdr.setFixedHeight(60)
        hl=QHBoxLayout(hdr); hl.setContentsMargins(20,0,20,0)
        logo_widget = QWidget(); logo_layout = QHBoxLayout(logo_widget); logo_layout.setContentsMargins(0,0,0,0); logo_layout.setSpacing(8)
        logo_icon = QLabel(); logo_icon.setPixmap(QPixmap(ICON_PATH).scaled(26, 26, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        logo_text = QLabel(APP_NAME); logo_text.setObjectName("Logo")
        logo_layout.addWidget(logo_icon); logo_layout.addWidget(logo_text)
        help=QPushButton(tr("hdr_help")); help.setObjectName("HelpBtn"); help.clicked.connect(self.help)
        sv=QPushButton(tr("hdr_servers")); sv.setObjectName("HeaderNav")
        sv.setCursor(QCursor(Qt.CursorShape.PointingHandCursor)); sv.clicked.connect(self.home)
        tl=QPushButton(tr("hdr_tools")); tl.setObjectName("HeaderNav")
        tl.setCursor(QCursor(Qt.CursorShape.PointingHandCursor)); tl.clicked.connect(self.tools)
        st=QPushButton(tr("hdr_settings")); st.setObjectName("HeaderNav")
        st.setCursor(QCursor(Qt.CursorShape.PointingHandCursor)); st.clicked.connect(self.settings)
        hl.addWidget(logo_widget); hl.addSpacing(20); hl.addWidget(help); hl.addStretch()
        hl.addWidget(sv); hl.addSpacing(15); hl.addWidget(tl); hl.addSpacing(15); hl.addWidget(st)
        self.stack=QStackedWidget()
        self.list_page=ServerListPage(); self.detail_page=ServerDetailPage(self)
        self.settings_page=SettingsTab(); self.tools_page=ToolsTab(self)
        self.stack.addWidget(self.list_page); self.stack.addWidget(self.detail_page)
        self.stack.addWidget(self.settings_page); self.stack.addWidget(self.tools_page)
        ml.addWidget(hdr); ml.addWidget(self.stack)
        self.list_page.server_selected.connect(self.open_server)
        QTimer.singleShot(500,self.startup_fix)
    def startup_fix(self):
        if os.name=='nt':
            try: subprocess.run(["taskkill","/F","/IM","java.exe"],capture_output=True,timeout=10,creationflags=subprocess.CREATE_NO_WINDOW)
            except: pass
    def tunnel_log(self, msg):
        if hasattr(self.detail_page,'console'): self.detail_page.console.append(f"[Tunnel] {msg}")
        if hasattr(self.tools_page,'log_msg'): self.tools_page.log_msg(msg)
    def start_tunnel(self):
        if not self.detail_page.current_server: return
        tp=self.detail_page.current_server.get("tunnel_provider","bore")
        port=self.detail_page.current_server.get("port","25565")
        mg=self.detail_page.current_server.get("manual_global","").strip()
        if mg: self.tunnel_log(f"Manual Global: {mg}"); self.detail_page.global_value.setText(mg); return
        if tp=="bore":
            if not bore_available(): self.tunnel_log("bore missing"); return
            self.bore.start(port)
        elif tp=="serveo":
            if not serveo_available(): self.tunnel_log("SSH missing"); return
            sub=self.detail_page.current_server.get("subdomain", f"agc-{random_name(6)}")
            self.serveo.start(port, sub)
        elif tp=="playit":
            if not playit_available(): self.tunnel_log("playit missing"); return
            self.playit.start()
    def stop_tunnel(self): self.bore.stop(); self.serveo.stop(); self.playit.stop()
    def bore_address(self, host, port):
        addr=f"{host}:{port}"
        self.tunnel_log(f"🌐 Bore: {addr}")
        self.detail_page.set_global_addr(addr, self.detail_page.current_server.get("bedrock_port","19132") if self.detail_page.current_server else None)
    def serveo_address(self, host, port):
        addr=f"{host}:{port}"
        self.tunnel_log(f"📌 Serveo: {addr}")
        self.detail_page.set_global_addr(addr, self.detail_page.current_server.get("bedrock_port","19132") if self.detail_page.current_server else None)
    def playit_address(self, addr):
        self.tunnel_log(f"🎯 playit: {addr}")
        self.detail_page.set_global_addr(addr, self.detail_page.current_server.get("bedrock_port","19132") if self.detail_page.current_server else None)
    def playit_manual(self):
        self.tunnel_log("playit: manually setup karein")
    def ensure_geyser(self):
        if not self.detail_page.current_server: return
        if not self.detail_page.current_server.get("bedrock_enabled",False): return
        sd=self.detail_page.current_server["dir"]; pd=os.path.join(sd,"plugins"); os.makedirs(pd,exist_ok=True)
        has_geyser=any(f.lower().startswith("geyser") and f.endswith(".jar") for f in os.listdir(pd)) if os.path.exists(pd) else False
        has_flood=any(f.lower().startswith("floodgate") and f.endswith(".jar") for f in os.listdir(pd)) if os.path.exists(pd) else False
        v=self.detail_page.current_server.get("version","latest")
        if not has_geyser:
            self.tunnel_log("Installing GeyserMC...")
            dl=ModrinthDownloader("geyser",v,pd); self.detail_page._geyser_dl=dl
            dl.finished.connect(lambda ok,msg: self.after_geyser(ok,msg,sd)); dl.start()
        if not has_flood:
            self.tunnel_log("Installing Floodgate...")
            dl=ModrinthDownloader("floodgate",v,pd); self.detail_page._flood_dl=dl; dl.start()
        if has_geyser: QTimer.singleShot(1000, lambda: self.edit_geyser(sd))
    def after_geyser(self, ok, msg, sd):
        self.tunnel_log(f"Geyser: {msg}")
        QTimer.singleShot(2000, lambda: self.edit_geyser(sd))
    def edit_geyser(self, sd):
        bp=self.detail_page.current_server.get("bedrock_port","19132") if self.detail_page.current_server else "19132"
        n=edit_geyser_config(sd,bp)
        if n: self.tunnel_log(f"Geyser config edited ({n})")
    def home(self): self.list_page.refresh(); self.stack.setCurrentIndex(0)
    def settings(self): self.stack.setCurrentIndex(2)
    def tools(self): self.stack.setCurrentIndex(3)
    def open_server(self,data): self.detail_page.set_server(data); self.stack.setCurrentIndex(1)
    def help(self):
        QMessageBox.information(self,tr("help_title"),tr("help_text"))
    def closeEvent(self,e):
        if self.detail_page.process.state()==QProcess.ProcessState.Running:
            if QMessageBox.question(self,tr("quit_title"),tr("quit_msg"))==QMessageBox.StandardButton.Yes:
                self.detail_page.process.write(b"stop\n"); self.detail_page.process.waitForFinished(5000)
                self.bore.stop(); self.serveo.stop(); self.playit.stop()
            else: e.ignore(); return
        else:
            self.bore.stop(); self.serveo.stop(); self.playit.stop()
        e.accept()

if __name__=="__main__":
    app=QApplication(sys.argv)
    app_icon=QIcon(ICON_PATH)
    app.setWindowIcon(app_icon)
    splash=make_splash(); splash.show()
    apply_language(app)
    apply_theme(app)
    QApplication.processEvents()
    w=MainWindow(); w.setWindowIcon(app_icon)
    def show_main(): splash.finish(w); w.show()
    QTimer.singleShot(2500, show_main)
    sys.exit(app.exec())